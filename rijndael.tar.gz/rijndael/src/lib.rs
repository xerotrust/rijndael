pub mod constants;  //allow users of the library to use these variables associated with this lib

struct Counter{
    rounds : usize,
    columns : usize,
    i : usize,
    c : usize,
    r : usize,
}
impl Counter{
    pub fn new(rounds_input : usize, columns_input : usize)->Counter{
        Counter{
            rounds : rounds_input,
            columns : columns_input,
            i : 0,
            c : 0,
            r : 0
        }
    }
    pub fn increment(&mut self){
        if self.r < 3{
            self.r = self.r+1;
        } else {
            self.r = 0;
            if self.c < (self.columns-1){
                self.c = self.c+1;
            } else {
                self.c = 0;
                if self.i < self.rounds-1{
                    self.i= self.i+1;
                } else {
                    self.i = 0;
                }
            }
        }
    }
}

/***************************************************************************************************
 * function name:  expand_key_(KEY_SIZE)_(BLOCK_SIZE)
 *
 * function:       (self explanatory)
 *
 * arguments:      expanded_key = the expanded key to use
 *                 key = raw key bits
 *
 * return:         void
 *
 * notes:          (none)
 **************************************************************************************************/


pub fn print_key_expansion_128_128(expanded_key : & [[[u8;constants::BLOCK_COLUMNS_128_128];4];constants::ROUNDS_128_128]){
    for i in 0..constants::ROUNDS_128_128{
        for c in 0..constants::BLOCK_COLUMNS_128_128{
            for r in 0..4{
                print!("{:02X} ",expanded_key[i][r][c]);
            }
        }
        println!();
    }
    println!();
}


fn print_block_128_128(message : &str, block : &[[u8;constants::BLOCK_COLUMNS_128_128];4]){
    println!("{}", message);
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_128{
            print!("{:02X} ", block[r][c]);
        }
        println!();
    }
    println!();
}

fn combo_move_128_128(temp :&mut  [[u8;constants::KEY_COLUMNS_128_128];4], round_constant_index : usize){
    for r in 0..4{
        temp[r][0] ^= constants::SBOX_FORWARD[temp[(r+1)%4][constants::KEY_COLUMNS_128_128-1] as usize];
    }
    temp[0][0] ^= constants::ROUND_CONSTANTS[round_constant_index];
}
fn swoosh_move_128_128(temp  : &mut [[u8;constants::KEY_COLUMNS_128_128];4] ){
    /*
    if constants::KEY_COLUMNS_128_128 < 6{
    */
        for c in 1..constants::KEY_COLUMNS_128_128{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    /*
    } else {
        for c in 1..4{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
        for r in 0..4{
            temp[r][4] ^= constants::SBOX_FORWARD[temp[r][3]as usize];
        }
        for c in 1..constants::KEY_COLUMNS_128_128{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    }
    */
}
fn load_move_128_128(temp : &[[u8;constants::KEY_COLUMNS_128_128];4],
expand_key : &mut [[[u8;constants::BLOCK_COLUMNS_128_128];4];constants::ROUNDS_128_128],
loads : usize,
expand_key_counter : &mut Counter){
    for c in 0..loads{
        for r in 0..4{
            expand_key[expand_key_counter.i][expand_key_counter.r][expand_key_counter.c]=temp[r][c];
            expand_key_counter.increment();
        }
    }
}

pub fn expand_key_128_128(key : &[u8;constants::KEY_BYTES_128_128],
expanded_key : &mut [[[u8;constants::BLOCK_COLUMNS_128_128];4];constants::ROUNDS_128_128]){
    //load into a local variable
    let mut round_constant_index : usize = 0;
    let mut temp : [[u8;constants::KEY_COLUMNS_128_128];4] =[[0;constants::KEY_COLUMNS_128_128];4];
    let mut expand_key_counter : Counter = Counter::new(constants::ROUNDS_128_128, constants::BLOCK_COLUMNS_128_128);
	let total_columns_needed : usize = constants::ROUNDS_128_128*constants::BLOCK_COLUMNS_128_128-constants::KEY_COLUMNS_128_128;
    let key_expansion_rounds_needed :usize = total_columns_needed/constants::KEY_COLUMNS_128_128;
    let key_expansion_remainder : usize = total_columns_needed%constants::KEY_COLUMNS_128_128;

    //load key into temporary matrix
    for c in 0..constants::KEY_COLUMNS_128_128{
        for r in 0..4{
            temp[r][c] = key[round_constant_index];
            round_constant_index+=1;
        }
    }
    //move temp into expanded key
    load_move_128_128(&temp, expanded_key, constants::KEY_COLUMNS_128_128, &mut expand_key_counter);
    //processing different for each type
    for round_constant_index in 1..key_expansion_rounds_needed+1{
        combo_move_128_128(&mut temp, round_constant_index);
        swoosh_move_128_128(&mut temp);
        load_move_128_128(&temp, expanded_key, constants::KEY_COLUMNS_128_128, &mut expand_key_counter);
    }
    if key_expansion_remainder > 0{
        combo_move_128_128(&mut temp, key_expansion_rounds_needed+1);
        swoosh_move_128_128(&mut temp);
        load_move_128_128(&temp, expanded_key, key_expansion_remainder, &mut expand_key_counter);
    }

}

pub fn encrypt_block_128_128(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_128_128];4];constants::ROUNDS_128_128],
input_block : & [u8;constants::BLOCK_BYTES_128_128],
destination_block : &mut [u8;constants::BLOCK_BYTES_128_128]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_128_128];4] = [[0;constants::BLOCK_COLUMNS_128_128];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_128_128];4];constants::ROUNDS_128_128] =
								[[[0;constants::BLOCK_COLUMNS_128_128];4];constants::ROUNDS_128_128];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_128_128{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_128{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_128_128{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }
    //add round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_128{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }
    //PROCESS ROUNDS
    for round in 1..(constants::ROUNDS_128_128-1){
        //substitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_128{
                local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
            }
        }

        //rotate rows
        for r in 1..4{
            let shift : usize = constants::SHIFTS_128_128[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_128_128-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_128_128-shift)..constants::BLOCK_COLUMNS_128_128{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_128_128];
            }
        }
        //mix_columns
        for c in 0..constants::BLOCK_COLUMNS_128_128{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_FORWARD[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_FORWARD[r][i]);
                }
            }
        }
        //add round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_128{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
    }
    //substitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_128{
            local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
        }
    }
    //rotate rows
    for r in 1..4{
            let shift : usize = constants::SHIFTS_128_128[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_128_128-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_128_128-shift)..constants::BLOCK_COLUMNS_128_128{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_128_128];
            }
    }
    //add final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_128{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_128_128-1][r][c];
        }
    }
    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_128_128{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


pub fn decrypt_block_128_128(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_128_128];4];constants::ROUNDS_128_128],
input_block : & [u8;constants::BLOCK_BYTES_128_128],
destination_block : &mut [u8;constants::BLOCK_BYTES_128_128]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_128_128];4] = [[0;constants::BLOCK_COLUMNS_128_128];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_128_128];4];constants::ROUNDS_128_128] =
								[[[0;constants::BLOCK_COLUMNS_128_128];4];constants::ROUNDS_128_128];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_128_128{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_128{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_128_128{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }

    //minus final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_128{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_128_128-1][r][c];
        }
    }

    //unrotate_rows
    for r in 1..4{
        let shift : usize = constants::SHIFTS_128_128[r];
        for i in (constants::BLOCK_COLUMNS_128_128-shift)..constants::BLOCK_COLUMNS_128_128{
            buffer[i+shift-constants::BLOCK_COLUMNS_128_128] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_128_128).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
    }

    //unsubstitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_128{
            local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
        }
    }

    for round in (1..(constants::ROUNDS_128_128-1)).rev(){
        //minus round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_128{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
        //unmix_columns
        for c in 0..constants::BLOCK_COLUMNS_128_128{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_REVERSE[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_REVERSE[r][i]);
                }
            }
        }

        //unrotate_rows
        for r in 1..4{
        let shift : usize = constants::SHIFTS_128_128[r];
        for i in (constants::BLOCK_COLUMNS_128_128-shift)..constants::BLOCK_COLUMNS_128_128{
            buffer[i+shift-constants::BLOCK_COLUMNS_128_128] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_128_128).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
        }

        //unsubstitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_128{
                local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
            }
        }


    }

    //minus round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_128{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }

    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_128_128{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


/***************************************************************************************************
 * function name:  expand_key_(KEY_SIZE)_(BLOCK_SIZE)
 *
 * function:       (self explanatory)
 *
 * arguments:      expanded_key = the expanded key to use
 *                 key = raw key bits
 *
 * return:         void
 *
 * notes:          (none)
 **************************************************************************************************/


pub fn print_key_expansion_128_160(expanded_key : & [[[u8;constants::BLOCK_COLUMNS_128_160];4];constants::ROUNDS_128_160]){
    for i in 0..constants::ROUNDS_128_160{
        for c in 0..constants::BLOCK_COLUMNS_128_160{
            for r in 0..4{
                print!("{:02X} ",expanded_key[i][r][c]);
            }
        }
        println!();
    }
    println!();
}


fn print_block_128_160(message : &str, block : &[[u8;constants::BLOCK_COLUMNS_128_160];4]){
    println!("{}", message);
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_160{
            print!("{:02X} ", block[r][c]);
        }
        println!();
    }
    println!();
}

fn combo_move_128_160(temp :&mut  [[u8;constants::KEY_COLUMNS_128_160];4], round_constant_index : usize){
    for r in 0..4{
        temp[r][0] ^= constants::SBOX_FORWARD[temp[(r+1)%4][constants::KEY_COLUMNS_128_160-1] as usize];
    }
    temp[0][0] ^= constants::ROUND_CONSTANTS[round_constant_index];
}
fn swoosh_move_128_160(temp  : &mut [[u8;constants::KEY_COLUMNS_128_160];4] ){
    /*
    if constants::KEY_COLUMNS_128_160 < 6{
    */
        for c in 1..constants::KEY_COLUMNS_128_160{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    /*
    } else {
        for c in 1..4{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
        for r in 0..4{
            temp[r][4] ^= constants::SBOX_FORWARD[temp[r][3]as usize];
        }
        for c in 1..constants::KEY_COLUMNS_128_160{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    }
    */
}
fn load_move_128_160(temp : &[[u8;constants::KEY_COLUMNS_128_160];4],
expand_key : &mut [[[u8;constants::BLOCK_COLUMNS_128_160];4];constants::ROUNDS_128_160],
loads : usize,
expand_key_counter : &mut Counter){
    for c in 0..loads{
        for r in 0..4{
            expand_key[expand_key_counter.i][expand_key_counter.r][expand_key_counter.c]=temp[r][c];
            expand_key_counter.increment();
        }
    }
}

pub fn expand_key_128_160(key : &[u8;constants::KEY_BYTES_128_160],
expanded_key : &mut [[[u8;constants::BLOCK_COLUMNS_128_160];4];constants::ROUNDS_128_160]){
    //load into a local variable
    let mut round_constant_index : usize = 0;
    let mut temp : [[u8;constants::KEY_COLUMNS_128_160];4] =[[0;constants::KEY_COLUMNS_128_160];4];
    let mut expand_key_counter : Counter = Counter::new(constants::ROUNDS_128_160, constants::BLOCK_COLUMNS_128_160);
	let total_columns_needed : usize = constants::ROUNDS_128_160*constants::BLOCK_COLUMNS_128_160-constants::KEY_COLUMNS_128_160;
    let key_expansion_rounds_needed :usize = total_columns_needed/constants::KEY_COLUMNS_128_160;
    let key_expansion_remainder : usize = total_columns_needed%constants::KEY_COLUMNS_128_160;

    //load key into temporary matrix
    for c in 0..constants::KEY_COLUMNS_128_160{
        for r in 0..4{
            temp[r][c] = key[round_constant_index];
            round_constant_index+=1;
        }
    }
    //move temp into expanded key
    load_move_128_160(&temp, expanded_key, constants::KEY_COLUMNS_128_160, &mut expand_key_counter);
    //processing different for each type
    for round_constant_index in 1..key_expansion_rounds_needed+1{
        combo_move_128_160(&mut temp, round_constant_index);
        swoosh_move_128_160(&mut temp);
        load_move_128_160(&temp, expanded_key, constants::KEY_COLUMNS_128_160, &mut expand_key_counter);
    }
    if key_expansion_remainder > 0{
        combo_move_128_160(&mut temp, key_expansion_rounds_needed+1);
        swoosh_move_128_160(&mut temp);
        load_move_128_160(&temp, expanded_key, key_expansion_remainder, &mut expand_key_counter);
    }

}

pub fn encrypt_block_128_160(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_128_160];4];constants::ROUNDS_128_160],
input_block : & [u8;constants::BLOCK_BYTES_128_160],
destination_block : &mut [u8;constants::BLOCK_BYTES_128_160]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_128_160];4] = [[0;constants::BLOCK_COLUMNS_128_160];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_128_160];4];constants::ROUNDS_128_160] =
								[[[0;constants::BLOCK_COLUMNS_128_160];4];constants::ROUNDS_128_160];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_128_160{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_160{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_128_160{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }
    //add round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_160{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }
    //PROCESS ROUNDS
    for round in 1..(constants::ROUNDS_128_160-1){
        //substitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_160{
                local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
            }
        }

        //rotate rows
        for r in 1..4{
            let shift : usize = constants::SHIFTS_128_160[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_128_160-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_128_160-shift)..constants::BLOCK_COLUMNS_128_160{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_128_160];
            }
        }
        //mix_columns
        for c in 0..constants::BLOCK_COLUMNS_128_160{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_FORWARD[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_FORWARD[r][i]);
                }
            }
        }
        //add round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_160{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
    }
    //substitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_160{
            local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
        }
    }
    //rotate rows
    for r in 1..4{
            let shift : usize = constants::SHIFTS_128_160[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_128_160-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_128_160-shift)..constants::BLOCK_COLUMNS_128_160{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_128_160];
            }
    }
    //add final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_160{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_128_160-1][r][c];
        }
    }
    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_128_160{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


pub fn decrypt_block_128_160(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_128_160];4];constants::ROUNDS_128_160],
input_block : & [u8;constants::BLOCK_BYTES_128_160],
destination_block : &mut [u8;constants::BLOCK_BYTES_128_160]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_128_160];4] = [[0;constants::BLOCK_COLUMNS_128_160];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_128_160];4];constants::ROUNDS_128_160] =
								[[[0;constants::BLOCK_COLUMNS_128_160];4];constants::ROUNDS_128_160];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_128_160{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_160{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_128_160{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }

    //minus final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_160{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_128_160-1][r][c];
        }
    }

    //unrotate_rows
    for r in 1..4{
        let shift : usize = constants::SHIFTS_128_160[r];
        for i in (constants::BLOCK_COLUMNS_128_160-shift)..constants::BLOCK_COLUMNS_128_160{
            buffer[i+shift-constants::BLOCK_COLUMNS_128_160] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_128_160).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
    }

    //unsubstitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_160{
            local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
        }
    }

    for round in (1..(constants::ROUNDS_128_160-1)).rev(){
        //minus round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_160{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
        //unmix_columns
        for c in 0..constants::BLOCK_COLUMNS_128_160{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_REVERSE[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_REVERSE[r][i]);
                }
            }
        }

        //unrotate_rows
        for r in 1..4{
        let shift : usize = constants::SHIFTS_128_160[r];
        for i in (constants::BLOCK_COLUMNS_128_160-shift)..constants::BLOCK_COLUMNS_128_160{
            buffer[i+shift-constants::BLOCK_COLUMNS_128_160] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_128_160).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
        }

        //unsubstitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_160{
                local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
            }
        }


    }

    //minus round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_160{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }

    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_128_160{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}

/***************************************************************************************************
 * function name:  expand_key_(KEY_SIZE)_(BLOCK_SIZE)
 *
 * function:       (self explanatory)
 *
 * arguments:      expanded_key = the expanded key to use
 *                 key = raw key bits
 *
 * return:         void
 *
 * notes:          (none)
 **************************************************************************************************/


pub fn print_key_expansion_128_192(expanded_key : & [[[u8;constants::BLOCK_COLUMNS_128_192];4];constants::ROUNDS_128_192]){
    for i in 0..constants::ROUNDS_128_192{
        for c in 0..constants::BLOCK_COLUMNS_128_192{
            for r in 0..4{
                print!("{:02X} ",expanded_key[i][r][c]);
            }
        }
        println!();
    }
    println!();
}


fn print_block_128_192(message : &str, block : &[[u8;constants::BLOCK_COLUMNS_128_192];4]){
    println!("{}", message);
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_192{
            print!("{:02X} ", block[r][c]);
        }
        println!();
    }
    println!();
}

fn combo_move_128_192(temp :&mut  [[u8;constants::KEY_COLUMNS_128_192];4], round_constant_index : usize){
    for r in 0..4{
        temp[r][0] ^= constants::SBOX_FORWARD[temp[(r+1)%4][constants::KEY_COLUMNS_128_192-1] as usize];
    }
    temp[0][0] ^= constants::ROUND_CONSTANTS[round_constant_index];
}
fn swoosh_move_128_192(temp  : &mut [[u8;constants::KEY_COLUMNS_128_192];4] ){
    /*
    if constants::KEY_COLUMNS_128_192 < 6{
    */
        for c in 1..constants::KEY_COLUMNS_128_192{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    /*
    } else {
        for c in 1..4{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
        for r in 0..4{
            temp[r][4] ^= constants::SBOX_FORWARD[temp[r][3]as usize];
        }
        for c in 1..constants::KEY_COLUMNS_128_192{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    }
    */
}
fn load_move_128_192(temp : &[[u8;constants::KEY_COLUMNS_128_192];4],
expand_key : &mut [[[u8;constants::BLOCK_COLUMNS_128_192];4];constants::ROUNDS_128_192],
loads : usize,
expand_key_counter : &mut Counter){
    for c in 0..loads{
        for r in 0..4{
            expand_key[expand_key_counter.i][expand_key_counter.r][expand_key_counter.c]=temp[r][c];
            expand_key_counter.increment();
        }
    }
}

pub fn expand_key_128_192(key : &[u8;constants::KEY_BYTES_128_192],
expanded_key : &mut [[[u8;constants::BLOCK_COLUMNS_128_192];4];constants::ROUNDS_128_192]){
    //load into a local variable
    let mut round_constant_index : usize = 0;
    let mut temp : [[u8;constants::KEY_COLUMNS_128_192];4] =[[0;constants::KEY_COLUMNS_128_192];4];
    let mut expand_key_counter : Counter = Counter::new(constants::ROUNDS_128_192, constants::BLOCK_COLUMNS_128_192);
	let total_columns_needed : usize = constants::ROUNDS_128_192*constants::BLOCK_COLUMNS_128_192-constants::KEY_COLUMNS_128_192;
    let key_expansion_rounds_needed :usize = total_columns_needed/constants::KEY_COLUMNS_128_192;
    let key_expansion_remainder : usize = total_columns_needed%constants::KEY_COLUMNS_128_192;

    //load key into temporary matrix
    for c in 0..constants::KEY_COLUMNS_128_192{
        for r in 0..4{
            temp[r][c] = key[round_constant_index];
            round_constant_index+=1;
        }
    }
    //move temp into expanded key
    load_move_128_192(&temp, expanded_key, constants::KEY_COLUMNS_128_192, &mut expand_key_counter);
    //processing different for each type
    for round_constant_index in 1..key_expansion_rounds_needed+1{
        combo_move_128_192(&mut temp, round_constant_index);
        swoosh_move_128_192(&mut temp);
        load_move_128_192(&temp, expanded_key, constants::KEY_COLUMNS_128_192, &mut expand_key_counter);
    }
    if key_expansion_remainder > 0{
        combo_move_128_192(&mut temp, key_expansion_rounds_needed+1);
        swoosh_move_128_192(&mut temp);
        load_move_128_192(&temp, expanded_key, key_expansion_remainder, &mut expand_key_counter);
    }

}

pub fn encrypt_block_128_192(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_128_192];4];constants::ROUNDS_128_192],
input_block : & [u8;constants::BLOCK_BYTES_128_192],
destination_block : &mut [u8;constants::BLOCK_BYTES_128_192]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_128_192];4] = [[0;constants::BLOCK_COLUMNS_128_192];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_128_192];4];constants::ROUNDS_128_192] =
								[[[0;constants::BLOCK_COLUMNS_128_192];4];constants::ROUNDS_128_192];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_128_192{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_192{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_128_192{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }
    //add round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_192{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }
    //PROCESS ROUNDS
    for round in 1..(constants::ROUNDS_128_192-1){
        //substitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_192{
                local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
            }
        }

        //rotate rows
        for r in 1..4{
            let shift : usize = constants::SHIFTS_128_192[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_128_192-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_128_192-shift)..constants::BLOCK_COLUMNS_128_192{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_128_192];
            }
        }
        //mix_columns
        for c in 0..constants::BLOCK_COLUMNS_128_192{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_FORWARD[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_FORWARD[r][i]);
                }
            }
        }
        //add round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_192{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
    }
    //substitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_192{
            local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
        }
    }
    //rotate rows
    for r in 1..4{
            let shift : usize = constants::SHIFTS_128_192[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_128_192-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_128_192-shift)..constants::BLOCK_COLUMNS_128_192{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_128_192];
            }
    }
    //add final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_192{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_128_192-1][r][c];
        }
    }
    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_128_192{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


pub fn decrypt_block_128_192(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_128_192];4];constants::ROUNDS_128_192],
input_block : & [u8;constants::BLOCK_BYTES_128_192],
destination_block : &mut [u8;constants::BLOCK_BYTES_128_192]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_128_192];4] = [[0;constants::BLOCK_COLUMNS_128_192];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_128_192];4];constants::ROUNDS_128_192] =
								[[[0;constants::BLOCK_COLUMNS_128_192];4];constants::ROUNDS_128_192];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_128_192{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_192{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_128_192{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }

    //minus final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_192{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_128_192-1][r][c];
        }
    }

    //unrotate_rows
    for r in 1..4{
        let shift : usize = constants::SHIFTS_128_192[r];
        for i in (constants::BLOCK_COLUMNS_128_192-shift)..constants::BLOCK_COLUMNS_128_192{
            buffer[i+shift-constants::BLOCK_COLUMNS_128_192] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_128_192).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
    }

    //unsubstitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_192{
            local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
        }
    }

    for round in (1..(constants::ROUNDS_128_192-1)).rev(){
        //minus round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_192{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
        //unmix_columns
        for c in 0..constants::BLOCK_COLUMNS_128_192{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_REVERSE[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_REVERSE[r][i]);
                }
            }
        }

        //unrotate_rows
        for r in 1..4{
        let shift : usize = constants::SHIFTS_128_192[r];
        for i in (constants::BLOCK_COLUMNS_128_192-shift)..constants::BLOCK_COLUMNS_128_192{
            buffer[i+shift-constants::BLOCK_COLUMNS_128_192] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_128_192).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
        }

        //unsubstitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_192{
                local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
            }
        }


    }

    //minus round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_192{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }

    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_128_192{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}
/***************************************************************************************************
 * function name:  multiply_gf256
 *
 * function:       multiplies two byte values in galois field 256
 *
 * arguments:      a = first byte
 *                 b = second byte
 *
 * return:         returns the gf product
 *
 * notes:          (none)
 **************************************************************************************************/
fn multilply_gf256(a : u8, b : u8)->u8{
    if a > 0 && b > 0 {
        return constants::ALOG_TABLE[(constants::LOG_TABLE[a as usize] as usize +
        constants::LOG_TABLE[b as usize] as usize)%255] as u8;
    }
    else {return 0;}
}


/***************************************************************************************************
 * function name:  expand_key_(KEY_SIZE)_(BLOCK_SIZE)
 *
 * function:       (self explanatory)
 *
 * arguments:      expanded_key = the expanded key to use
 *                 key = raw key bits
 *
 * return:         void
 *
 * notes:          (none)
 **************************************************************************************************/


pub fn print_key_expansion_128_224(expanded_key : & [[[u8;constants::BLOCK_COLUMNS_128_224];4];constants::ROUNDS_128_224]){
    for i in 0..constants::ROUNDS_128_224{
        for c in 0..constants::BLOCK_COLUMNS_128_224{
            for r in 0..4{
                print!("{:02X} ",expanded_key[i][r][c]);
            }
        }
        println!();
    }
    println!();
}


fn print_block_128_224(message : &str, block : &[[u8;constants::BLOCK_COLUMNS_128_224];4]){
    println!("{}", message);
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_224{
            print!("{:02X} ", block[r][c]);
        }
        println!();
    }
    println!();
}

fn combo_move_128_224(temp :&mut  [[u8;constants::KEY_COLUMNS_128_224];4], round_constant_index : usize){
    for r in 0..4{
        temp[r][0] ^= constants::SBOX_FORWARD[temp[(r+1)%4][constants::KEY_COLUMNS_128_224-1] as usize];
    }
    temp[0][0] ^= constants::ROUND_CONSTANTS[round_constant_index];
}
fn swoosh_move_128_224(temp  : &mut [[u8;constants::KEY_COLUMNS_128_224];4] ){
    /*
    if constants::KEY_COLUMNS_128_224 < 6{
    */
        for c in 1..constants::KEY_COLUMNS_128_224{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    /*
    } else {
        for c in 1..4{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
        for r in 0..4{
            temp[r][4] ^= constants::SBOX_FORWARD[temp[r][3]as usize];
        }
        for c in 1..constants::KEY_COLUMNS_128_224{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    }
    */
}
fn load_move_128_224(temp : &[[u8;constants::KEY_COLUMNS_128_224];4],
expand_key : &mut [[[u8;constants::BLOCK_COLUMNS_128_224];4];constants::ROUNDS_128_224],
loads : usize,
expand_key_counter : &mut Counter){
    for c in 0..loads{
        for r in 0..4{
            expand_key[expand_key_counter.i][expand_key_counter.r][expand_key_counter.c]=temp[r][c];
            expand_key_counter.increment();
        }
    }
}

pub fn expand_key_128_224(key : &[u8;constants::KEY_BYTES_128_224],
expanded_key : &mut [[[u8;constants::BLOCK_COLUMNS_128_224];4];constants::ROUNDS_128_224]){
    //load into a local variable
    let mut round_constant_index : usize = 0;
    let mut temp : [[u8;constants::KEY_COLUMNS_128_224];4] =[[0;constants::KEY_COLUMNS_128_224];4];
    let mut expand_key_counter : Counter = Counter::new(constants::ROUNDS_128_224, constants::BLOCK_COLUMNS_128_224);
	let total_columns_needed : usize = constants::ROUNDS_128_224*constants::BLOCK_COLUMNS_128_224-constants::KEY_COLUMNS_128_224;
    let key_expansion_rounds_needed :usize = total_columns_needed/constants::KEY_COLUMNS_128_224;
    let key_expansion_remainder : usize = total_columns_needed%constants::KEY_COLUMNS_128_224;

    //load key into temporary matrix
    for c in 0..constants::KEY_COLUMNS_128_224{
        for r in 0..4{
            temp[r][c] = key[round_constant_index];
            round_constant_index+=1;
        }
    }
    //move temp into expanded key
    load_move_128_224(&temp, expanded_key, constants::KEY_COLUMNS_128_224, &mut expand_key_counter);
    //processing different for each type
    for round_constant_index in 1..key_expansion_rounds_needed+1{
        combo_move_128_224(&mut temp, round_constant_index);
        swoosh_move_128_224(&mut temp);
        load_move_128_224(&temp, expanded_key, constants::KEY_COLUMNS_128_224, &mut expand_key_counter);
    }
    if key_expansion_remainder > 0{
        combo_move_128_224(&mut temp, key_expansion_rounds_needed+1);
        swoosh_move_128_224(&mut temp);
        load_move_128_224(&temp, expanded_key, key_expansion_remainder, &mut expand_key_counter);
    }

}

pub fn encrypt_block_128_224(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_128_224];4];constants::ROUNDS_128_224],
input_block : & [u8;constants::BLOCK_BYTES_128_224],
destination_block : &mut [u8;constants::BLOCK_BYTES_128_224]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_128_224];4] = [[0;constants::BLOCK_COLUMNS_128_224];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_128_224];4];constants::ROUNDS_128_224] =
								[[[0;constants::BLOCK_COLUMNS_128_224];4];constants::ROUNDS_128_224];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_128_224{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_224{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_128_224{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }
    //add round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_224{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }
    //PROCESS ROUNDS
    for round in 1..(constants::ROUNDS_128_224-1){
        //substitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_224{
                local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
            }
        }

        //rotate rows
        for r in 1..4{
            let shift : usize = constants::SHIFTS_128_224[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_128_224-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_128_224-shift)..constants::BLOCK_COLUMNS_128_224{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_128_224];
            }
        }
        //mix_columns
        for c in 0..constants::BLOCK_COLUMNS_128_224{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_FORWARD[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_FORWARD[r][i]);
                }
            }
        }
        //add round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_224{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
    }
    //substitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_224{
            local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
        }
    }
    //rotate rows
    for r in 1..4{
            let shift : usize = constants::SHIFTS_128_224[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_128_224-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_128_224-shift)..constants::BLOCK_COLUMNS_128_224{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_128_224];
            }
    }
    //add final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_224{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_128_224-1][r][c];
        }
    }
    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_128_224{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


pub fn decrypt_block_128_224(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_128_224];4];constants::ROUNDS_128_224],
input_block : & [u8;constants::BLOCK_BYTES_128_224],
destination_block : &mut [u8;constants::BLOCK_BYTES_128_224]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_128_224];4] = [[0;constants::BLOCK_COLUMNS_128_224];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_128_224];4];constants::ROUNDS_128_224] =
								[[[0;constants::BLOCK_COLUMNS_128_224];4];constants::ROUNDS_128_224];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_128_224{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_224{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_128_224{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }

    //minus final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_224{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_128_224-1][r][c];
        }
    }

    //unrotate_rows
    for r in 1..4{
        let shift : usize = constants::SHIFTS_128_224[r];
        for i in (constants::BLOCK_COLUMNS_128_224-shift)..constants::BLOCK_COLUMNS_128_224{
            buffer[i+shift-constants::BLOCK_COLUMNS_128_224] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_128_224).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
    }

    //unsubstitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_224{
            local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
        }
    }

    for round in (1..(constants::ROUNDS_128_224-1)).rev(){
        //minus round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_224{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
        //unmix_columns
        for c in 0..constants::BLOCK_COLUMNS_128_224{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_REVERSE[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_REVERSE[r][i]);
                }
            }
        }

        //unrotate_rows
        for r in 1..4{
        let shift : usize = constants::SHIFTS_128_224[r];
        for i in (constants::BLOCK_COLUMNS_128_224-shift)..constants::BLOCK_COLUMNS_128_224{
            buffer[i+shift-constants::BLOCK_COLUMNS_128_224] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_128_224).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
        }

        //unsubstitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_224{
                local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
            }
        }


    }

    //minus round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_224{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }

    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_128_224{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}

/***************************************************************************************************
 * function name:  expand_key_(KEY_SIZE)_(BLOCK_SIZE)
 *
 * function:       (self explanatory)
 *
 * arguments:      expanded_key = the expanded key to use
 *                 key = raw key bits
 *
 * return:         void
 *
 * notes:          (none)
 **************************************************************************************************/


pub fn print_key_expansion_128_256(expanded_key : & [[[u8;constants::BLOCK_COLUMNS_128_256];4];constants::ROUNDS_128_256]){
    for i in 0..constants::ROUNDS_128_256{
        for c in 0..constants::BLOCK_COLUMNS_128_256{
            for r in 0..4{
                print!("{:02X} ",expanded_key[i][r][c]);
            }
        }
        println!();
    }
    println!();
}


fn print_block_128_256(message : &str, block : &[[u8;constants::BLOCK_COLUMNS_128_256];4]){
    println!("{}", message);
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_256{
            print!("{:02X} ", block[r][c]);
        }
        println!();
    }
    println!();
}

fn combo_move_128_256(temp :&mut  [[u8;constants::KEY_COLUMNS_128_256];4], round_constant_index : usize){
    for r in 0..4{
        temp[r][0] ^= constants::SBOX_FORWARD[temp[(r+1)%4][constants::KEY_COLUMNS_128_256-1] as usize];
    }
    temp[0][0] ^= constants::ROUND_CONSTANTS[round_constant_index];
}
fn swoosh_move_128_256(temp  : &mut [[u8;constants::KEY_COLUMNS_128_256];4] ){
    /*
    if constants::KEY_COLUMNS_128_256 < 6{
    */
        for c in 1..constants::KEY_COLUMNS_128_256{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    /*
    } else {
        for c in 1..4{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
        for r in 0..4{
            temp[r][4] ^= constants::SBOX_FORWARD[temp[r][3]as usize];
        }
        for c in 1..constants::KEY_COLUMNS_128_256{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    }
    */
}
fn load_move_128_256(temp : &[[u8;constants::KEY_COLUMNS_128_256];4],
expand_key : &mut [[[u8;constants::BLOCK_COLUMNS_128_256];4];constants::ROUNDS_128_256],
loads : usize,
expand_key_counter : &mut Counter){
    for c in 0..loads{
        for r in 0..4{
            expand_key[expand_key_counter.i][expand_key_counter.r][expand_key_counter.c]=temp[r][c];
            expand_key_counter.increment();
        }
    }
}

pub fn expand_key_128_256(key : &[u8;constants::KEY_BYTES_128_256],
expanded_key : &mut [[[u8;constants::BLOCK_COLUMNS_128_256];4];constants::ROUNDS_128_256]){
    //load into a local variable
    let mut round_constant_index : usize = 0;
    let mut temp : [[u8;constants::KEY_COLUMNS_128_256];4] =[[0;constants::KEY_COLUMNS_128_256];4];
    let mut expand_key_counter : Counter = Counter::new(constants::ROUNDS_128_256, constants::BLOCK_COLUMNS_128_256);
	let total_columns_needed : usize = constants::ROUNDS_128_256*constants::BLOCK_COLUMNS_128_256-constants::KEY_COLUMNS_128_256;
    let key_expansion_rounds_needed :usize = total_columns_needed/constants::KEY_COLUMNS_128_256;
    let key_expansion_remainder : usize = total_columns_needed%constants::KEY_COLUMNS_128_256;

    //load key into temporary matrix
    for c in 0..constants::KEY_COLUMNS_128_256{
        for r in 0..4{
            temp[r][c] = key[round_constant_index];
            round_constant_index+=1;
        }
    }
    //move temp into expanded key
    load_move_128_256(&temp, expanded_key, constants::KEY_COLUMNS_128_256, &mut expand_key_counter);
    //processing different for each type
    for round_constant_index in 1..key_expansion_rounds_needed+1{
        combo_move_128_256(&mut temp, round_constant_index);
        swoosh_move_128_256(&mut temp);
        load_move_128_256(&temp, expanded_key, constants::KEY_COLUMNS_128_256, &mut expand_key_counter);
    }
    if key_expansion_remainder > 0{
        combo_move_128_256(&mut temp, key_expansion_rounds_needed+1);
        swoosh_move_128_256(&mut temp);
        load_move_128_256(&temp, expanded_key, key_expansion_remainder, &mut expand_key_counter);
    }

}

pub fn encrypt_block_128_256(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_128_256];4];constants::ROUNDS_128_256],
input_block : & [u8;constants::BLOCK_BYTES_128_256],
destination_block : &mut [u8;constants::BLOCK_BYTES_128_256]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_128_256];4] = [[0;constants::BLOCK_COLUMNS_128_256];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_128_256];4];constants::ROUNDS_128_256] =
								[[[0;constants::BLOCK_COLUMNS_128_256];4];constants::ROUNDS_128_256];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_128_256{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_256{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_128_256{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }
    //add round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_256{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }
    //PROCESS ROUNDS
    for round in 1..(constants::ROUNDS_128_256-1){
        //substitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_256{
                local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
            }
        }

        //rotate rows
        for r in 1..4{
            let shift : usize = constants::SHIFTS_128_256[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_128_256-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_128_256-shift)..constants::BLOCK_COLUMNS_128_256{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_128_256];
            }
        }
        //mix_columns
        for c in 0..constants::BLOCK_COLUMNS_128_256{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_FORWARD[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_FORWARD[r][i]);
                }
            }
        }
        //add round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_256{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
    }
    //substitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_256{
            local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
        }
    }
    //rotate rows
    for r in 1..4{
            let shift : usize = constants::SHIFTS_128_256[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_128_256-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_128_256-shift)..constants::BLOCK_COLUMNS_128_256{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_128_256];
            }
    }
    //add final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_256{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_128_256-1][r][c];
        }
    }
    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_128_256{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


pub fn decrypt_block_128_256(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_128_256];4];constants::ROUNDS_128_256],
input_block : & [u8;constants::BLOCK_BYTES_128_256],
destination_block : &mut [u8;constants::BLOCK_BYTES_128_256]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_128_256];4] = [[0;constants::BLOCK_COLUMNS_128_256];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_128_256];4];constants::ROUNDS_128_256] =
								[[[0;constants::BLOCK_COLUMNS_128_256];4];constants::ROUNDS_128_256];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_128_256{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_256{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_128_256{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }

    //minus final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_256{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_128_256-1][r][c];
        }
    }

    //unrotate_rows
    for r in 1..4{
        let shift : usize = constants::SHIFTS_128_256[r];
        for i in (constants::BLOCK_COLUMNS_128_256-shift)..constants::BLOCK_COLUMNS_128_256{
            buffer[i+shift-constants::BLOCK_COLUMNS_128_256] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_128_256).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
    }

    //unsubstitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_256{
            local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
        }
    }

    for round in (1..(constants::ROUNDS_128_256-1)).rev(){
        //minus round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_256{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
        //unmix_columns
        for c in 0..constants::BLOCK_COLUMNS_128_256{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_REVERSE[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_REVERSE[r][i]);
                }
            }
        }

        //unrotate_rows
        for r in 1..4{
        let shift : usize = constants::SHIFTS_128_256[r];
        for i in (constants::BLOCK_COLUMNS_128_256-shift)..constants::BLOCK_COLUMNS_128_256{
            buffer[i+shift-constants::BLOCK_COLUMNS_128_256] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_128_256).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
        }

        //unsubstitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_128_256{
                local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
            }
        }


    }

    //minus round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_128_256{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }

    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_128_256{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}

/***************************************************************************************************
 * function name:  expand_key_(KEY_SIZE)_(BLOCK_SIZE)
 *
 * function:       (self explanatory)
 *
 * arguments:      expanded_key = the expanded key to use
 *                 key = raw key bits
 *
 * return:         void
 *
 * notes:          (none)
 **************************************************************************************************/


pub fn print_key_expansion_160_128(expanded_key : & [[[u8;constants::BLOCK_COLUMNS_160_128];4];constants::ROUNDS_160_128]){
    for i in 0..constants::ROUNDS_160_128{
        for c in 0..constants::BLOCK_COLUMNS_160_128{
            for r in 0..4{
                print!("{:02X} ",expanded_key[i][r][c]);
            }
        }
        println!();
    }
    println!();
}


fn print_block_160_128(message : &str, block : &[[u8;constants::BLOCK_COLUMNS_160_128];4]){
    println!("{}", message);
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_128{
            print!("{:02X} ", block[r][c]);
        }
        println!();
    }
    println!();
}

fn combo_move_160_128(temp :&mut  [[u8;constants::KEY_COLUMNS_160_128];4], round_constant_index : usize){
    for r in 0..4{
        temp[r][0] ^= constants::SBOX_FORWARD[temp[(r+1)%4][constants::KEY_COLUMNS_160_128-1] as usize];
    }
    temp[0][0] ^= constants::ROUND_CONSTANTS[round_constant_index];
}
fn swoosh_move_160_128(temp  : &mut [[u8;constants::KEY_COLUMNS_160_128];4] ){
    /*
    if constants::KEY_COLUMNS_160_128 < 6{
    */
        for c in 1..constants::KEY_COLUMNS_160_128{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    /*
    } else {
        for c in 1..4{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
        for r in 0..4{
            temp[r][4] ^= constants::SBOX_FORWARD[temp[r][3]as usize];
        }
        for c in 1..constants::KEY_COLUMNS_160_128{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    }
    */
}
fn load_move_160_128(temp : &[[u8;constants::KEY_COLUMNS_160_128];4],
expand_key : &mut [[[u8;constants::BLOCK_COLUMNS_160_128];4];constants::ROUNDS_160_128],
loads : usize,
expand_key_counter : &mut Counter){
    for c in 0..loads{
        for r in 0..4{
            expand_key[expand_key_counter.i][expand_key_counter.r][expand_key_counter.c]=temp[r][c];
            expand_key_counter.increment();
        }
    }
}

pub fn expand_key_160_128(key : &[u8;constants::KEY_BYTES_160_128],
expanded_key : &mut [[[u8;constants::BLOCK_COLUMNS_160_128];4];constants::ROUNDS_160_128]){
    //load into a local variable
    let mut round_constant_index : usize = 0;
    let mut temp : [[u8;constants::KEY_COLUMNS_160_128];4] =[[0;constants::KEY_COLUMNS_160_128];4];
    let mut expand_key_counter : Counter = Counter::new(constants::ROUNDS_160_128, constants::BLOCK_COLUMNS_160_128);
	let total_columns_needed : usize = constants::ROUNDS_160_128*constants::BLOCK_COLUMNS_160_128-constants::KEY_COLUMNS_160_128;
    let key_expansion_rounds_needed :usize = total_columns_needed/constants::KEY_COLUMNS_160_128;
    let key_expansion_remainder : usize = total_columns_needed%constants::KEY_COLUMNS_160_128;

    //load key into temporary matrix
    for c in 0..constants::KEY_COLUMNS_160_128{
        for r in 0..4{
            temp[r][c] = key[round_constant_index];
            round_constant_index+=1;
        }
    }
    //move temp into expanded key
    load_move_160_128(&temp, expanded_key, constants::KEY_COLUMNS_160_128, &mut expand_key_counter);
    //processing different for each type
    for round_constant_index in 1..key_expansion_rounds_needed+1{
        combo_move_160_128(&mut temp, round_constant_index);
        swoosh_move_160_128(&mut temp);
        load_move_160_128(&temp, expanded_key, constants::KEY_COLUMNS_160_128, &mut expand_key_counter);
    }
    if key_expansion_remainder > 0{
        combo_move_160_128(&mut temp, key_expansion_rounds_needed+1);
        swoosh_move_160_128(&mut temp);
        load_move_160_128(&temp, expanded_key, key_expansion_remainder, &mut expand_key_counter);
    }

}

pub fn encrypt_block_160_128(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_160_128];4];constants::ROUNDS_160_128],
input_block : & [u8;constants::BLOCK_BYTES_160_128],
destination_block : &mut [u8;constants::BLOCK_BYTES_160_128]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_160_128];4] = [[0;constants::BLOCK_COLUMNS_160_128];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_160_128];4];constants::ROUNDS_160_128] =
								[[[0;constants::BLOCK_COLUMNS_160_128];4];constants::ROUNDS_160_128];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_160_128{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_128{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_160_128{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }
    //add round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_128{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }
    //PROCESS ROUNDS
    for round in 1..(constants::ROUNDS_160_128-1){
        //substitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_128{
                local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
            }
        }

        //rotate rows
        for r in 1..4{
            let shift : usize = constants::SHIFTS_160_128[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_160_128-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_160_128-shift)..constants::BLOCK_COLUMNS_160_128{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_160_128];
            }
        }
        //mix_columns
        for c in 0..constants::BLOCK_COLUMNS_160_128{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_FORWARD[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_FORWARD[r][i]);
                }
            }
        }
        //add round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_128{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
    }
    //substitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_128{
            local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
        }
    }
    //rotate rows
    for r in 1..4{
            let shift : usize = constants::SHIFTS_160_128[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_160_128-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_160_128-shift)..constants::BLOCK_COLUMNS_160_128{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_160_128];
            }
    }
    //add final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_128{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_160_128-1][r][c];
        }
    }
    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_160_128{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


pub fn decrypt_block_160_128(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_160_128];4];constants::ROUNDS_160_128],
input_block : & [u8;constants::BLOCK_BYTES_160_128],
destination_block : &mut [u8;constants::BLOCK_BYTES_160_128]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_160_128];4] = [[0;constants::BLOCK_COLUMNS_160_128];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_160_128];4];constants::ROUNDS_160_128] =
								[[[0;constants::BLOCK_COLUMNS_160_128];4];constants::ROUNDS_160_128];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_160_128{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_128{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_160_128{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }

    //minus final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_128{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_160_128-1][r][c];
        }
    }

    //unrotate_rows
    for r in 1..4{
        let shift : usize = constants::SHIFTS_160_128[r];
        for i in (constants::BLOCK_COLUMNS_160_128-shift)..constants::BLOCK_COLUMNS_160_128{
            buffer[i+shift-constants::BLOCK_COLUMNS_160_128] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_160_128).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
    }

    //unsubstitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_128{
            local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
        }
    }

    for round in (1..(constants::ROUNDS_160_128-1)).rev(){
        //minus round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_128{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
        //unmix_columns
        for c in 0..constants::BLOCK_COLUMNS_160_128{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_REVERSE[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_REVERSE[r][i]);
                }
            }
        }

        //unrotate_rows
        for r in 1..4{
        let shift : usize = constants::SHIFTS_160_128[r];
        for i in (constants::BLOCK_COLUMNS_160_128-shift)..constants::BLOCK_COLUMNS_160_128{
            buffer[i+shift-constants::BLOCK_COLUMNS_160_128] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_160_128).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
        }

        //unsubstitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_128{
                local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
            }
        }


    }

    //minus round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_128{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }

    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_160_128{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


/***************************************************************************************************
 * function name:  expand_key_(KEY_SIZE)_(BLOCK_SIZE)
 *
 * function:       (self explanatory)
 *
 * arguments:      expanded_key = the expanded key to use
 *                 key = raw key bits
 *
 * return:         void
 *
 * notes:          (none)
 **************************************************************************************************/


pub fn print_key_expansion_160_160(expanded_key : & [[[u8;constants::BLOCK_COLUMNS_160_160];4];constants::ROUNDS_160_160]){
    for i in 0..constants::ROUNDS_160_160{
        for c in 0..constants::BLOCK_COLUMNS_160_160{
            for r in 0..4{
                print!("{:02X} ",expanded_key[i][r][c]);
            }
        }
        println!();
    }
    println!();
}


fn print_block_160_160(message : &str, block : &[[u8;constants::BLOCK_COLUMNS_160_160];4]){
    println!("{}", message);
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_160{
            print!("{:02X} ", block[r][c]);
        }
        println!();
    }
    println!();
}

fn combo_move_160_160(temp :&mut  [[u8;constants::KEY_COLUMNS_160_160];4], round_constant_index : usize){
    for r in 0..4{
        temp[r][0] ^= constants::SBOX_FORWARD[temp[(r+1)%4][constants::KEY_COLUMNS_160_160-1] as usize];
    }
    temp[0][0] ^= constants::ROUND_CONSTANTS[round_constant_index];
}
fn swoosh_move_160_160(temp  : &mut [[u8;constants::KEY_COLUMNS_160_160];4] ){
    /*
    if constants::KEY_COLUMNS_160_160 < 6{
    */
        for c in 1..constants::KEY_COLUMNS_160_160{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    /*
    } else {
        for c in 1..4{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
        for r in 0..4{
            temp[r][4] ^= constants::SBOX_FORWARD[temp[r][3]as usize];
        }
        for c in 1..constants::KEY_COLUMNS_160_160{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    }
    */
}
fn load_move_160_160(temp : &[[u8;constants::KEY_COLUMNS_160_160];4],
expand_key : &mut [[[u8;constants::BLOCK_COLUMNS_160_160];4];constants::ROUNDS_160_160],
loads : usize,
expand_key_counter : &mut Counter){
    for c in 0..loads{
        for r in 0..4{
            expand_key[expand_key_counter.i][expand_key_counter.r][expand_key_counter.c]=temp[r][c];
            expand_key_counter.increment();
        }
    }
}

pub fn expand_key_160_160(key : &[u8;constants::KEY_BYTES_160_160],
expanded_key : &mut [[[u8;constants::BLOCK_COLUMNS_160_160];4];constants::ROUNDS_160_160]){
    //load into a local variable
    let mut round_constant_index : usize = 0;
    let mut temp : [[u8;constants::KEY_COLUMNS_160_160];4] =[[0;constants::KEY_COLUMNS_160_160];4];
    let mut expand_key_counter : Counter = Counter::new(constants::ROUNDS_160_160, constants::BLOCK_COLUMNS_160_160);
	let total_columns_needed : usize = constants::ROUNDS_160_160*constants::BLOCK_COLUMNS_160_160-constants::KEY_COLUMNS_160_160;
    let key_expansion_rounds_needed :usize = total_columns_needed/constants::KEY_COLUMNS_160_160;
    let key_expansion_remainder : usize = total_columns_needed%constants::KEY_COLUMNS_160_160;

    //load key into temporary matrix
    for c in 0..constants::KEY_COLUMNS_160_160{
        for r in 0..4{
            temp[r][c] = key[round_constant_index];
            round_constant_index+=1;
        }
    }
    //move temp into expanded key
    load_move_160_160(&temp, expanded_key, constants::KEY_COLUMNS_160_160, &mut expand_key_counter);
    //processing different for each type
    for round_constant_index in 1..key_expansion_rounds_needed+1{
        combo_move_160_160(&mut temp, round_constant_index);
        swoosh_move_160_160(&mut temp);
        load_move_160_160(&temp, expanded_key, constants::KEY_COLUMNS_160_160, &mut expand_key_counter);
    }
    if key_expansion_remainder > 0{
        combo_move_160_160(&mut temp, key_expansion_rounds_needed+1);
        swoosh_move_160_160(&mut temp);
        load_move_160_160(&temp, expanded_key, key_expansion_remainder, &mut expand_key_counter);
    }

}

pub fn encrypt_block_160_160(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_160_160];4];constants::ROUNDS_160_160],
input_block : & [u8;constants::BLOCK_BYTES_160_160],
destination_block : &mut [u8;constants::BLOCK_BYTES_160_160]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_160_160];4] = [[0;constants::BLOCK_COLUMNS_160_160];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_160_160];4];constants::ROUNDS_160_160] =
								[[[0;constants::BLOCK_COLUMNS_160_160];4];constants::ROUNDS_160_160];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_160_160{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_160{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_160_160{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }
    //add round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_160{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }
    //PROCESS ROUNDS
    for round in 1..(constants::ROUNDS_160_160-1){
        //substitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_160{
                local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
            }
        }

        //rotate rows
        for r in 1..4{
            let shift : usize = constants::SHIFTS_160_160[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_160_160-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_160_160-shift)..constants::BLOCK_COLUMNS_160_160{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_160_160];
            }
        }
        //mix_columns
        for c in 0..constants::BLOCK_COLUMNS_160_160{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_FORWARD[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_FORWARD[r][i]);
                }
            }
        }
        //add round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_160{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
    }
    //substitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_160{
            local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
        }
    }
    //rotate rows
    for r in 1..4{
            let shift : usize = constants::SHIFTS_160_160[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_160_160-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_160_160-shift)..constants::BLOCK_COLUMNS_160_160{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_160_160];
            }
    }
    //add final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_160{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_160_160-1][r][c];
        }
    }
    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_160_160{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


pub fn decrypt_block_160_160(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_160_160];4];constants::ROUNDS_160_160],
input_block : & [u8;constants::BLOCK_BYTES_160_160],
destination_block : &mut [u8;constants::BLOCK_BYTES_160_160]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_160_160];4] = [[0;constants::BLOCK_COLUMNS_160_160];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_160_160];4];constants::ROUNDS_160_160] =
								[[[0;constants::BLOCK_COLUMNS_160_160];4];constants::ROUNDS_160_160];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_160_160{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_160{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_160_160{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }

    //minus final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_160{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_160_160-1][r][c];
        }
    }

    //unrotate_rows
    for r in 1..4{
        let shift : usize = constants::SHIFTS_160_160[r];
        for i in (constants::BLOCK_COLUMNS_160_160-shift)..constants::BLOCK_COLUMNS_160_160{
            buffer[i+shift-constants::BLOCK_COLUMNS_160_160] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_160_160).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
    }

    //unsubstitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_160{
            local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
        }
    }

    for round in (1..(constants::ROUNDS_160_160-1)).rev(){
        //minus round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_160{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
        //unmix_columns
        for c in 0..constants::BLOCK_COLUMNS_160_160{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_REVERSE[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_REVERSE[r][i]);
                }
            }
        }

        //unrotate_rows
        for r in 1..4{
        let shift : usize = constants::SHIFTS_160_160[r];
        for i in (constants::BLOCK_COLUMNS_160_160-shift)..constants::BLOCK_COLUMNS_160_160{
            buffer[i+shift-constants::BLOCK_COLUMNS_160_160] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_160_160).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
        }

        //unsubstitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_160{
                local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
            }
        }


    }

    //minus round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_160{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }

    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_160_160{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


/***************************************************************************************************
 * function name:  expand_key_(KEY_SIZE)_(BLOCK_SIZE)
 *
 * function:       (self explanatory)
 *
 * arguments:      expanded_key = the expanded key to use
 *                 key = raw key bits
 *
 * return:         void
 *
 * notes:          (none)
 **************************************************************************************************/


pub fn print_key_expansion_160_192(expanded_key : & [[[u8;constants::BLOCK_COLUMNS_160_192];4];constants::ROUNDS_160_192]){
    for i in 0..constants::ROUNDS_160_192{
        for c in 0..constants::BLOCK_COLUMNS_160_192{
            for r in 0..4{
                print!("{:02X} ",expanded_key[i][r][c]);
            }
        }
        println!();
    }
    println!();
}


fn print_block_160_192(message : &str, block : &[[u8;constants::BLOCK_COLUMNS_160_192];4]){
    println!("{}", message);
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_192{
            print!("{:02X} ", block[r][c]);
        }
        println!();
    }
    println!();
}

fn combo_move_160_192(temp :&mut  [[u8;constants::KEY_COLUMNS_160_192];4], round_constant_index : usize){
    for r in 0..4{
        temp[r][0] ^= constants::SBOX_FORWARD[temp[(r+1)%4][constants::KEY_COLUMNS_160_192-1] as usize];
    }
    temp[0][0] ^= constants::ROUND_CONSTANTS[round_constant_index];
}
fn swoosh_move_160_192(temp  : &mut [[u8;constants::KEY_COLUMNS_160_192];4] ){
    /*
    if constants::KEY_COLUMNS_160_192 < 6{
    */
        for c in 1..constants::KEY_COLUMNS_160_192{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    /*
    } else {
        for c in 1..4{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
        for r in 0..4{
            temp[r][4] ^= constants::SBOX_FORWARD[temp[r][3]as usize];
        }
        for c in 1..constants::KEY_COLUMNS_160_192{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    }
    */
}
fn load_move_160_192(temp : &[[u8;constants::KEY_COLUMNS_160_192];4],
expand_key : &mut [[[u8;constants::BLOCK_COLUMNS_160_192];4];constants::ROUNDS_160_192],
loads : usize,
expand_key_counter : &mut Counter){
    for c in 0..loads{
        for r in 0..4{
            expand_key[expand_key_counter.i][expand_key_counter.r][expand_key_counter.c]=temp[r][c];
            expand_key_counter.increment();
        }
    }
}

pub fn expand_key_160_192(key : &[u8;constants::KEY_BYTES_160_192],
expanded_key : &mut [[[u8;constants::BLOCK_COLUMNS_160_192];4];constants::ROUNDS_160_192]){
    //load into a local variable
    let mut round_constant_index : usize = 0;
    let mut temp : [[u8;constants::KEY_COLUMNS_160_192];4] =[[0;constants::KEY_COLUMNS_160_192];4];
    let mut expand_key_counter : Counter = Counter::new(constants::ROUNDS_160_192, constants::BLOCK_COLUMNS_160_192);
	let total_columns_needed : usize = constants::ROUNDS_160_192*constants::BLOCK_COLUMNS_160_192-constants::KEY_COLUMNS_160_192;
    let key_expansion_rounds_needed :usize = total_columns_needed/constants::KEY_COLUMNS_160_192;
    let key_expansion_remainder : usize = total_columns_needed%constants::KEY_COLUMNS_160_192;

    //load key into temporary matrix
    for c in 0..constants::KEY_COLUMNS_160_192{
        for r in 0..4{
            temp[r][c] = key[round_constant_index];
            round_constant_index+=1;
        }
    }
    //move temp into expanded key
    load_move_160_192(&temp, expanded_key, constants::KEY_COLUMNS_160_192, &mut expand_key_counter);
    //processing different for each type
    for round_constant_index in 1..key_expansion_rounds_needed+1{
        combo_move_160_192(&mut temp, round_constant_index);
        swoosh_move_160_192(&mut temp);
        load_move_160_192(&temp, expanded_key, constants::KEY_COLUMNS_160_192, &mut expand_key_counter);
    }
    if key_expansion_remainder > 0{
        combo_move_160_192(&mut temp, key_expansion_rounds_needed+1);
        swoosh_move_160_192(&mut temp);
        load_move_160_192(&temp, expanded_key, key_expansion_remainder, &mut expand_key_counter);
    }

}

pub fn encrypt_block_160_192(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_160_192];4];constants::ROUNDS_160_192],
input_block : & [u8;constants::BLOCK_BYTES_160_192],
destination_block : &mut [u8;constants::BLOCK_BYTES_160_192]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_160_192];4] = [[0;constants::BLOCK_COLUMNS_160_192];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_160_192];4];constants::ROUNDS_160_192] =
								[[[0;constants::BLOCK_COLUMNS_160_192];4];constants::ROUNDS_160_192];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_160_192{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_192{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_160_192{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }
    //add round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_192{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }
    //PROCESS ROUNDS
    for round in 1..(constants::ROUNDS_160_192-1){
        //substitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_192{
                local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
            }
        }

        //rotate rows
        for r in 1..4{
            let shift : usize = constants::SHIFTS_160_192[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_160_192-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_160_192-shift)..constants::BLOCK_COLUMNS_160_192{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_160_192];
            }
        }
        //mix_columns
        for c in 0..constants::BLOCK_COLUMNS_160_192{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_FORWARD[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_FORWARD[r][i]);
                }
            }
        }
        //add round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_192{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
    }
    //substitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_192{
            local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
        }
    }
    //rotate rows
    for r in 1..4{
            let shift : usize = constants::SHIFTS_160_192[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_160_192-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_160_192-shift)..constants::BLOCK_COLUMNS_160_192{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_160_192];
            }
    }
    //add final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_192{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_160_192-1][r][c];
        }
    }
    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_160_192{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


pub fn decrypt_block_160_192(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_160_192];4];constants::ROUNDS_160_192],
input_block : & [u8;constants::BLOCK_BYTES_160_192],
destination_block : &mut [u8;constants::BLOCK_BYTES_160_192]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_160_192];4] = [[0;constants::BLOCK_COLUMNS_160_192];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_160_192];4];constants::ROUNDS_160_192] =
								[[[0;constants::BLOCK_COLUMNS_160_192];4];constants::ROUNDS_160_192];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_160_192{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_192{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_160_192{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }

    //minus final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_192{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_160_192-1][r][c];
        }
    }

    //unrotate_rows
    for r in 1..4{
        let shift : usize = constants::SHIFTS_160_192[r];
        for i in (constants::BLOCK_COLUMNS_160_192-shift)..constants::BLOCK_COLUMNS_160_192{
            buffer[i+shift-constants::BLOCK_COLUMNS_160_192] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_160_192).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
    }

    //unsubstitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_192{
            local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
        }
    }

    for round in (1..(constants::ROUNDS_160_192-1)).rev(){
        //minus round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_192{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
        //unmix_columns
        for c in 0..constants::BLOCK_COLUMNS_160_192{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_REVERSE[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_REVERSE[r][i]);
                }
            }
        }

        //unrotate_rows
        for r in 1..4{
        let shift : usize = constants::SHIFTS_160_192[r];
        for i in (constants::BLOCK_COLUMNS_160_192-shift)..constants::BLOCK_COLUMNS_160_192{
            buffer[i+shift-constants::BLOCK_COLUMNS_160_192] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_160_192).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
        }

        //unsubstitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_192{
                local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
            }
        }


    }

    //minus round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_192{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }

    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_160_192{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}

/***************************************************************************************************
 * function name:  expand_key_(KEY_SIZE)_(BLOCK_SIZE)
 *
 * function:       (self explanatory)
 *
 * arguments:      expanded_key = the expanded key to use
 *                 key = raw key bits
 *
 * return:         void
 *
 * notes:          (none)
 **************************************************************************************************/


pub fn print_key_expansion_160_224(expanded_key : & [[[u8;constants::BLOCK_COLUMNS_160_224];4];constants::ROUNDS_160_224]){
    for i in 0..constants::ROUNDS_160_224{
        for c in 0..constants::BLOCK_COLUMNS_160_224{
            for r in 0..4{
                print!("{:02X} ",expanded_key[i][r][c]);
            }
        }
        println!();
    }
    println!();
}


fn print_block_160_224(message : &str, block : &[[u8;constants::BLOCK_COLUMNS_160_224];4]){
    println!("{}", message);
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_224{
            print!("{:02X} ", block[r][c]);
        }
        println!();
    }
    println!();
}

fn combo_move_160_224(temp :&mut  [[u8;constants::KEY_COLUMNS_160_224];4], round_constant_index : usize){
    for r in 0..4{
        temp[r][0] ^= constants::SBOX_FORWARD[temp[(r+1)%4][constants::KEY_COLUMNS_160_224-1] as usize];
    }
    temp[0][0] ^= constants::ROUND_CONSTANTS[round_constant_index];
}
fn swoosh_move_160_224(temp  : &mut [[u8;constants::KEY_COLUMNS_160_224];4] ){
    /*
    if constants::KEY_COLUMNS_160_224 < 6{
    */
        for c in 1..constants::KEY_COLUMNS_160_224{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    /*
    } else {
        for c in 1..4{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
        for r in 0..4{
            temp[r][4] ^= constants::SBOX_FORWARD[temp[r][3]as usize];
        }
        for c in 1..constants::KEY_COLUMNS_160_224{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    }
    */
}
fn load_move_160_224(temp : &[[u8;constants::KEY_COLUMNS_160_224];4],
expand_key : &mut [[[u8;constants::BLOCK_COLUMNS_160_224];4];constants::ROUNDS_160_224],
loads : usize,
expand_key_counter : &mut Counter){
    for c in 0..loads{
        for r in 0..4{
            expand_key[expand_key_counter.i][expand_key_counter.r][expand_key_counter.c]=temp[r][c];
            expand_key_counter.increment();
        }
    }
}

pub fn expand_key_160_224(key : &[u8;constants::KEY_BYTES_160_224],
expanded_key : &mut [[[u8;constants::BLOCK_COLUMNS_160_224];4];constants::ROUNDS_160_224]){
    //load into a local variable
    let mut round_constant_index : usize = 0;
    let mut temp : [[u8;constants::KEY_COLUMNS_160_224];4] =[[0;constants::KEY_COLUMNS_160_224];4];
    let mut expand_key_counter : Counter = Counter::new(constants::ROUNDS_160_224, constants::BLOCK_COLUMNS_160_224);
	let total_columns_needed : usize = constants::ROUNDS_160_224*constants::BLOCK_COLUMNS_160_224-constants::KEY_COLUMNS_160_224;
    let key_expansion_rounds_needed :usize = total_columns_needed/constants::KEY_COLUMNS_160_224;
    let key_expansion_remainder : usize = total_columns_needed%constants::KEY_COLUMNS_160_224;

    //load key into temporary matrix
    for c in 0..constants::KEY_COLUMNS_160_224{
        for r in 0..4{
            temp[r][c] = key[round_constant_index];
            round_constant_index+=1;
        }
    }
    //move temp into expanded key
    load_move_160_224(&temp, expanded_key, constants::KEY_COLUMNS_160_224, &mut expand_key_counter);
    //processing different for each type
    for round_constant_index in 1..key_expansion_rounds_needed+1{
        combo_move_160_224(&mut temp, round_constant_index);
        swoosh_move_160_224(&mut temp);
        load_move_160_224(&temp, expanded_key, constants::KEY_COLUMNS_160_224, &mut expand_key_counter);
    }
    if key_expansion_remainder > 0{
        combo_move_160_224(&mut temp, key_expansion_rounds_needed+1);
        swoosh_move_160_224(&mut temp);
        load_move_160_224(&temp, expanded_key, key_expansion_remainder, &mut expand_key_counter);
    }

}

pub fn encrypt_block_160_224(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_160_224];4];constants::ROUNDS_160_224],
input_block : & [u8;constants::BLOCK_BYTES_160_224],
destination_block : &mut [u8;constants::BLOCK_BYTES_160_224]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_160_224];4] = [[0;constants::BLOCK_COLUMNS_160_224];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_160_224];4];constants::ROUNDS_160_224] =
								[[[0;constants::BLOCK_COLUMNS_160_224];4];constants::ROUNDS_160_224];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_160_224{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_224{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_160_224{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }
    //add round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_224{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }
    //PROCESS ROUNDS
    for round in 1..(constants::ROUNDS_160_224-1){
        //substitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_224{
                local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
            }
        }

        //rotate rows
        for r in 1..4{
            let shift : usize = constants::SHIFTS_160_224[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_160_224-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_160_224-shift)..constants::BLOCK_COLUMNS_160_224{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_160_224];
            }
        }
        //mix_columns
        for c in 0..constants::BLOCK_COLUMNS_160_224{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_FORWARD[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_FORWARD[r][i]);
                }
            }
        }
        //add round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_224{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
    }
    //substitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_224{
            local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
        }
    }
    //rotate rows
    for r in 1..4{
            let shift : usize = constants::SHIFTS_160_224[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_160_224-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_160_224-shift)..constants::BLOCK_COLUMNS_160_224{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_160_224];
            }
    }
    //add final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_224{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_160_224-1][r][c];
        }
    }
    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_160_224{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


pub fn decrypt_block_160_224(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_160_224];4];constants::ROUNDS_160_224],
input_block : & [u8;constants::BLOCK_BYTES_160_224],
destination_block : &mut [u8;constants::BLOCK_BYTES_160_224]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_160_224];4] = [[0;constants::BLOCK_COLUMNS_160_224];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_160_224];4];constants::ROUNDS_160_224] =
								[[[0;constants::BLOCK_COLUMNS_160_224];4];constants::ROUNDS_160_224];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_160_224{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_224{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_160_224{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }

    //minus final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_224{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_160_224-1][r][c];
        }
    }

    //unrotate_rows
    for r in 1..4{
        let shift : usize = constants::SHIFTS_160_224[r];
        for i in (constants::BLOCK_COLUMNS_160_224-shift)..constants::BLOCK_COLUMNS_160_224{
            buffer[i+shift-constants::BLOCK_COLUMNS_160_224] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_160_224).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
    }

    //unsubstitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_224{
            local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
        }
    }

    for round in (1..(constants::ROUNDS_160_224-1)).rev(){
        //minus round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_224{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
        //unmix_columns
        for c in 0..constants::BLOCK_COLUMNS_160_224{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_REVERSE[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_REVERSE[r][i]);
                }
            }
        }

        //unrotate_rows
        for r in 1..4{
        let shift : usize = constants::SHIFTS_160_224[r];
        for i in (constants::BLOCK_COLUMNS_160_224-shift)..constants::BLOCK_COLUMNS_160_224{
            buffer[i+shift-constants::BLOCK_COLUMNS_160_224] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_160_224).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
        }

        //unsubstitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_224{
                local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
            }
        }


    }

    //minus round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_224{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }

    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_160_224{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


/***************************************************************************************************
 * function name:  expand_key_(KEY_SIZE)_(BLOCK_SIZE)
 *
 * function:       (self explanatory)
 *
 * arguments:      expanded_key = the expanded key to use
 *                 key = raw key bits
 *
 * return:         void
 *
 * notes:          (none)
 **************************************************************************************************/


pub fn print_key_expansion_160_256(expanded_key : & [[[u8;constants::BLOCK_COLUMNS_160_256];4];constants::ROUNDS_160_256]){
    for i in 0..constants::ROUNDS_160_256{
        for c in 0..constants::BLOCK_COLUMNS_160_256{
            for r in 0..4{
                print!("{:02X} ",expanded_key[i][r][c]);
            }
        }
        println!();
    }
    println!();
}


fn print_block_160_256(message : &str, block : &[[u8;constants::BLOCK_COLUMNS_160_256];4]){
    println!("{}", message);
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_256{
            print!("{:02X} ", block[r][c]);
        }
        println!();
    }
    println!();
}

fn combo_move_160_256(temp :&mut  [[u8;constants::KEY_COLUMNS_160_256];4], round_constant_index : usize){
    for r in 0..4{
        temp[r][0] ^= constants::SBOX_FORWARD[temp[(r+1)%4][constants::KEY_COLUMNS_160_256-1] as usize];
    }
    temp[0][0] ^= constants::ROUND_CONSTANTS[round_constant_index];
}
fn swoosh_move_160_256(temp  : &mut [[u8;constants::KEY_COLUMNS_160_256];4] ){
    /*
    if constants::KEY_COLUMNS_160_256 < 6{
    */
        for c in 1..constants::KEY_COLUMNS_160_256{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    /*
    } else {
        for c in 1..4{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
        for r in 0..4{
            temp[r][4] ^= constants::SBOX_FORWARD[temp[r][3]as usize];
        }
        for c in 1..constants::KEY_COLUMNS_160_256{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    }
    */
}
fn load_move_160_256(temp : &[[u8;constants::KEY_COLUMNS_160_256];4],
expand_key : &mut [[[u8;constants::BLOCK_COLUMNS_160_256];4];constants::ROUNDS_160_256],
loads : usize,
expand_key_counter : &mut Counter){
    for c in 0..loads{
        for r in 0..4{
            expand_key[expand_key_counter.i][expand_key_counter.r][expand_key_counter.c]=temp[r][c];
            expand_key_counter.increment();
        }
    }
}

pub fn expand_key_160_256(key : &[u8;constants::KEY_BYTES_160_256],
expanded_key : &mut [[[u8;constants::BLOCK_COLUMNS_160_256];4];constants::ROUNDS_160_256]){
    //load into a local variable
    let mut round_constant_index : usize = 0;
    let mut temp : [[u8;constants::KEY_COLUMNS_160_256];4] =[[0;constants::KEY_COLUMNS_160_256];4];
    let mut expand_key_counter : Counter = Counter::new(constants::ROUNDS_160_256, constants::BLOCK_COLUMNS_160_256);
	let total_columns_needed : usize = constants::ROUNDS_160_256*constants::BLOCK_COLUMNS_160_256-constants::KEY_COLUMNS_160_256;
    let key_expansion_rounds_needed :usize = total_columns_needed/constants::KEY_COLUMNS_160_256;
    let key_expansion_remainder : usize = total_columns_needed%constants::KEY_COLUMNS_160_256;

    //load key into temporary matrix
    for c in 0..constants::KEY_COLUMNS_160_256{
        for r in 0..4{
            temp[r][c] = key[round_constant_index];
            round_constant_index+=1;
        }
    }
    //move temp into expanded key
    load_move_160_256(&temp, expanded_key, constants::KEY_COLUMNS_160_256, &mut expand_key_counter);
    //processing different for each type
    for round_constant_index in 1..key_expansion_rounds_needed+1{
        combo_move_160_256(&mut temp, round_constant_index);
        swoosh_move_160_256(&mut temp);
        load_move_160_256(&temp, expanded_key, constants::KEY_COLUMNS_160_256, &mut expand_key_counter);
    }
    if key_expansion_remainder > 0{
        combo_move_160_256(&mut temp, key_expansion_rounds_needed+1);
        swoosh_move_160_256(&mut temp);
        load_move_160_256(&temp, expanded_key, key_expansion_remainder, &mut expand_key_counter);
    }

}

pub fn encrypt_block_160_256(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_160_256];4];constants::ROUNDS_160_256],
input_block : & [u8;constants::BLOCK_BYTES_160_256],
destination_block : &mut [u8;constants::BLOCK_BYTES_160_256]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_160_256];4] = [[0;constants::BLOCK_COLUMNS_160_256];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_160_256];4];constants::ROUNDS_160_256] =
								[[[0;constants::BLOCK_COLUMNS_160_256];4];constants::ROUNDS_160_256];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_160_256{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_256{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_160_256{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }
    //add round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_256{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }
    //PROCESS ROUNDS
    for round in 1..(constants::ROUNDS_160_256-1){
        //substitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_256{
                local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
            }
        }

        //rotate rows
        for r in 1..4{
            let shift : usize = constants::SHIFTS_160_256[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_160_256-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_160_256-shift)..constants::BLOCK_COLUMNS_160_256{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_160_256];
            }
        }
        //mix_columns
        for c in 0..constants::BLOCK_COLUMNS_160_256{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_FORWARD[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_FORWARD[r][i]);
                }
            }
        }
        //add round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_256{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
    }
    //substitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_256{
            local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
        }
    }
    //rotate rows
    for r in 1..4{
            let shift : usize = constants::SHIFTS_160_256[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_160_256-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_160_256-shift)..constants::BLOCK_COLUMNS_160_256{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_160_256];
            }
    }
    //add final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_256{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_160_256-1][r][c];
        }
    }
    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_160_256{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


pub fn decrypt_block_160_256(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_160_256];4];constants::ROUNDS_160_256],
input_block : & [u8;constants::BLOCK_BYTES_160_256],
destination_block : &mut [u8;constants::BLOCK_BYTES_160_256]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_160_256];4] = [[0;constants::BLOCK_COLUMNS_160_256];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_160_256];4];constants::ROUNDS_160_256] =
								[[[0;constants::BLOCK_COLUMNS_160_256];4];constants::ROUNDS_160_256];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_160_256{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_256{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_160_256{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }

    //minus final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_256{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_160_256-1][r][c];
        }
    }

    //unrotate_rows
    for r in 1..4{
        let shift : usize = constants::SHIFTS_160_256[r];
        for i in (constants::BLOCK_COLUMNS_160_256-shift)..constants::BLOCK_COLUMNS_160_256{
            buffer[i+shift-constants::BLOCK_COLUMNS_160_256] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_160_256).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
    }

    //unsubstitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_256{
            local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
        }
    }

    for round in (1..(constants::ROUNDS_160_256-1)).rev(){
        //minus round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_256{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
        //unmix_columns
        for c in 0..constants::BLOCK_COLUMNS_160_256{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_REVERSE[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_REVERSE[r][i]);
                }
            }
        }

        //unrotate_rows
        for r in 1..4{
        let shift : usize = constants::SHIFTS_160_256[r];
        for i in (constants::BLOCK_COLUMNS_160_256-shift)..constants::BLOCK_COLUMNS_160_256{
            buffer[i+shift-constants::BLOCK_COLUMNS_160_256] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_160_256).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
        }

        //unsubstitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_160_256{
                local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
            }
        }


    }

    //minus round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_160_256{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }

    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_160_256{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}
/***************************************************************************************************
 * function name:  expand_key_(KEY_SIZE)_(BLOCK_SIZE)
 *
 * function:       (self explanatory)
 *
 * arguments:      expanded_key = the expanded key to use
 *                 key = raw key bits
 *
 * return:         void
 *
 * notes:          (none)
 **************************************************************************************************/


pub fn print_key_expansion_192_128(expanded_key : & [[[u8;constants::BLOCK_COLUMNS_192_128];4];constants::ROUNDS_192_128]){
    for i in 0..constants::ROUNDS_192_128{
        for c in 0..constants::BLOCK_COLUMNS_192_128{
            for r in 0..4{
                print!("{:02X} ",expanded_key[i][r][c]);
            }
        }
        println!();
    }
    println!();
}


fn print_block_192_128(message : &str, block : &[[u8;constants::BLOCK_COLUMNS_192_128];4]){
    println!("{}", message);
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_128{
            print!("{:02X} ", block[r][c]);
        }
        println!();
    }
    println!();
}

fn combo_move_192_128(temp :&mut  [[u8;constants::KEY_COLUMNS_192_128];4], round_constant_index : usize){
    for r in 0..4{
        temp[r][0] ^= constants::SBOX_FORWARD[temp[(r+1)%4][constants::KEY_COLUMNS_192_128-1] as usize];
    }
    temp[0][0] ^= constants::ROUND_CONSTANTS[round_constant_index];
}
fn swoosh_move_192_128(temp  : &mut [[u8;constants::KEY_COLUMNS_192_128];4] ){
    /*
    if constants::KEY_COLUMNS_192_128 < 6{
    */
        for c in 1..constants::KEY_COLUMNS_192_128{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    /*
    } else {

        for c in 1..4{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
        for r in 0..4{
            temp[r][4] ^= constants::SBOX_FORWARD[(temp[r][3])as usize];
        }
        for c in 5..constants::KEY_COLUMNS_192_128{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }

    }
    */
}
fn load_move_192_128(temp : &[[u8;constants::KEY_COLUMNS_192_128];4],
expand_key : &mut [[[u8;constants::BLOCK_COLUMNS_192_128];4];constants::ROUNDS_192_128],
loads : usize,
expand_key_counter : &mut Counter){
    for c in 0..loads{
        for r in 0..4{
            expand_key[expand_key_counter.i][expand_key_counter.r][expand_key_counter.c]=temp[r][c];
            expand_key_counter.increment();
        }
    }
}

pub fn expand_key_192_128(key : &[u8;constants::KEY_BYTES_192_128],
expanded_key : &mut [[[u8;constants::BLOCK_COLUMNS_192_128];4];constants::ROUNDS_192_128]){
    //load into a local variable
    let mut round_constant_index : usize = 0;
    let mut temp : [[u8;constants::KEY_COLUMNS_192_128];4] =[[0;constants::KEY_COLUMNS_192_128];4];
    let mut expand_key_counter : Counter = Counter::new(constants::ROUNDS_192_128, constants::BLOCK_COLUMNS_192_128);
	let total_columns_needed : usize = constants::ROUNDS_192_128*constants::BLOCK_COLUMNS_192_128-constants::KEY_COLUMNS_192_128;
    let key_expansion_rounds_needed :usize = total_columns_needed/constants::KEY_COLUMNS_192_128;
    let key_expansion_remainder : usize = total_columns_needed%constants::KEY_COLUMNS_192_128;

    //load key into temporary matrix
    for c in 0..constants::KEY_COLUMNS_192_128{
        for r in 0..4{
            temp[r][c] = key[round_constant_index];
            round_constant_index+=1;
        }
    }
    //move temp into expanded key
    load_move_192_128(&temp, expanded_key, constants::KEY_COLUMNS_192_128, &mut expand_key_counter);
    //processing different for each type
    for round_constant_index in 1..key_expansion_rounds_needed+1{
        combo_move_192_128(&mut temp, round_constant_index);
        swoosh_move_192_128(&mut temp);
        load_move_192_128(&temp, expanded_key, constants::KEY_COLUMNS_192_128, &mut expand_key_counter);
    }
    if key_expansion_remainder > 0{
        combo_move_192_128(&mut temp, key_expansion_rounds_needed+1);
        swoosh_move_192_128(&mut temp);
        load_move_192_128(&temp, expanded_key, key_expansion_remainder, &mut expand_key_counter);
    }

}

pub fn encrypt_block_192_128(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_192_128];4];constants::ROUNDS_192_128],
input_block : & [u8;constants::BLOCK_BYTES_192_128],
destination_block : &mut [u8;constants::BLOCK_BYTES_192_128]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_192_128];4] = [[0;constants::BLOCK_COLUMNS_192_128];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_192_128];4];constants::ROUNDS_192_128] =
								[[[0;constants::BLOCK_COLUMNS_192_128];4];constants::ROUNDS_192_128];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_192_128{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_128{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_192_128{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }
    //add round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_128{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }
    //PROCESS ROUNDS
    for round in 1..(constants::ROUNDS_192_128-1){
        //substitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_128{
                local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
            }
        }

        //rotate rows
        for r in 1..4{
            let shift : usize = constants::SHIFTS_192_128[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_192_128-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_192_128-shift)..constants::BLOCK_COLUMNS_192_128{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_192_128];
            }
        }
        //mix_columns
        for c in 0..constants::BLOCK_COLUMNS_192_128{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_FORWARD[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_FORWARD[r][i]);
                }
            }
        }
        //add round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_128{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
    }
    //substitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_128{
            local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
        }
    }
    //rotate rows
    for r in 1..4{
            let shift : usize = constants::SHIFTS_192_128[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_192_128-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_192_128-shift)..constants::BLOCK_COLUMNS_192_128{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_192_128];
            }
    }
    //add final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_128{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_192_128-1][r][c];
        }
    }
    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_192_128{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


pub fn decrypt_block_192_128(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_192_128];4];constants::ROUNDS_192_128],
input_block : & [u8;constants::BLOCK_BYTES_192_128],
destination_block : &mut [u8;constants::BLOCK_BYTES_192_128]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_192_128];4] = [[0;constants::BLOCK_COLUMNS_192_128];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_192_128];4];constants::ROUNDS_192_128] =
								[[[0;constants::BLOCK_COLUMNS_192_128];4];constants::ROUNDS_192_128];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_192_128{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_128{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_192_128{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }

    //minus final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_128{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_192_128-1][r][c];
        }
    }

    //unrotate_rows
    for r in 1..4{
        let shift : usize = constants::SHIFTS_192_128[r];
        for i in (constants::BLOCK_COLUMNS_192_128-shift)..constants::BLOCK_COLUMNS_192_128{
            buffer[i+shift-constants::BLOCK_COLUMNS_192_128] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_192_128).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
    }

    //unsubstitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_128{
            local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
        }
    }

    for round in (1..(constants::ROUNDS_192_128-1)).rev(){
        //minus round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_128{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
        //unmix_columns
        for c in 0..constants::BLOCK_COLUMNS_192_128{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_REVERSE[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_REVERSE[r][i]);
                }
            }
        }

        //unrotate_rows
        for r in 1..4{
        let shift : usize = constants::SHIFTS_192_128[r];
        for i in (constants::BLOCK_COLUMNS_192_128-shift)..constants::BLOCK_COLUMNS_192_128{
            buffer[i+shift-constants::BLOCK_COLUMNS_192_128] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_192_128).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
        }

        //unsubstitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_128{
                local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
            }
        }


    }

    //minus round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_128{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }

    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_192_128{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}



/***************************************************************************************************
 * function name:  expand_key_(KEY_SIZE)_(BLOCK_SIZE)
 *
 * function:       (self explanatory)
 *
 * arguments:      expanded_key = the expanded key to use
 *                 key = raw key bits
 *
 * return:         void
 *
 * notes:          (none)
 **************************************************************************************************/


pub fn print_key_expansion_192_192(expanded_key : & [[[u8;constants::BLOCK_COLUMNS_192_192];4];constants::ROUNDS_192_192]){
    for i in 0..constants::ROUNDS_192_192{
        for c in 0..constants::BLOCK_COLUMNS_192_192{
            for r in 0..4{
                print!("{:02X} ",expanded_key[i][r][c]);
            }
        }
        println!();
    }
    println!();
}


fn print_block_192_192(message : &str, block : &[[u8;constants::BLOCK_COLUMNS_192_192];4]){
    println!("{}", message);
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_192{
            print!("{:02X} ", block[r][c]);
        }
        println!();
    }
    println!();
}

fn combo_move_192_192(temp :&mut  [[u8;constants::KEY_COLUMNS_192_192];4], round_constant_index : usize){
    for r in 0..4{
        temp[r][0] ^= constants::SBOX_FORWARD[temp[(r+1)%4][constants::KEY_COLUMNS_192_192-1] as usize];
    }
    temp[0][0] ^= constants::ROUND_CONSTANTS[round_constant_index];
}
fn swoosh_move_192_192(temp  : &mut [[u8;constants::KEY_COLUMNS_192_192];4] ){
    /*
    if constants::KEY_COLUMNS_192_192 < 6{
    */
        for c in 1..constants::KEY_COLUMNS_192_192{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    /*
    } else {

        for c in 1..4{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
        for r in 0..4{
            temp[r][4] ^= constants::SBOX_FORWARD[(temp[r][3])as usize];
        }
        for c in 5..constants::KEY_COLUMNS_192_192{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }

    }
    */
}
fn load_move_192_192(temp : &[[u8;constants::KEY_COLUMNS_192_192];4],
expand_key : &mut [[[u8;constants::BLOCK_COLUMNS_192_192];4];constants::ROUNDS_192_192],
loads : usize,
expand_key_counter : &mut Counter){
    for c in 0..loads{
        for r in 0..4{
            expand_key[expand_key_counter.i][expand_key_counter.r][expand_key_counter.c]=temp[r][c];
            expand_key_counter.increment();
        }
    }
}

pub fn expand_key_192_192(key : &[u8;constants::KEY_BYTES_192_192],
expanded_key : &mut [[[u8;constants::BLOCK_COLUMNS_192_192];4];constants::ROUNDS_192_192]){
    //load into a local variable
    let mut round_constant_index : usize = 0;
    let mut temp : [[u8;constants::KEY_COLUMNS_192_192];4] =[[0;constants::KEY_COLUMNS_192_192];4];
    let mut expand_key_counter : Counter = Counter::new(constants::ROUNDS_192_192, constants::BLOCK_COLUMNS_192_192);
	let total_columns_needed : usize = constants::ROUNDS_192_192*constants::BLOCK_COLUMNS_192_192-constants::KEY_COLUMNS_192_192;
    let key_expansion_rounds_needed :usize = total_columns_needed/constants::KEY_COLUMNS_192_192;
    let key_expansion_remainder : usize = total_columns_needed%constants::KEY_COLUMNS_192_192;

    //load key into temporary matrix
    for c in 0..constants::KEY_COLUMNS_192_192{
        for r in 0..4{
            temp[r][c] = key[round_constant_index];
            round_constant_index+=1;
        }
    }
    //move temp into expanded key
    load_move_192_192(&temp, expanded_key, constants::KEY_COLUMNS_192_192, &mut expand_key_counter);
    //processing different for each type
    for round_constant_index in 1..key_expansion_rounds_needed+1{
        combo_move_192_192(&mut temp, round_constant_index);
        swoosh_move_192_192(&mut temp);
        load_move_192_192(&temp, expanded_key, constants::KEY_COLUMNS_192_192, &mut expand_key_counter);
    }
    if key_expansion_remainder > 0{
        combo_move_192_192(&mut temp, key_expansion_rounds_needed+1);
        swoosh_move_192_192(&mut temp);
        load_move_192_192(&temp, expanded_key, key_expansion_remainder, &mut expand_key_counter);
    }

}

pub fn encrypt_block_192_192(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_192_192];4];constants::ROUNDS_192_192],
input_block : & [u8;constants::BLOCK_BYTES_192_192],
destination_block : &mut [u8;constants::BLOCK_BYTES_192_192]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_192_192];4] = [[0;constants::BLOCK_COLUMNS_192_192];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_192_192];4];constants::ROUNDS_192_192] =
								[[[0;constants::BLOCK_COLUMNS_192_192];4];constants::ROUNDS_192_192];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_192_192{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_192{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_192_192{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }
    //add round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_192{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }
    //PROCESS ROUNDS
    for round in 1..(constants::ROUNDS_192_192-1){
        //substitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_192{
                local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
            }
        }

        //rotate rows
        for r in 1..4{
            let shift : usize = constants::SHIFTS_192_192[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_192_192-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_192_192-shift)..constants::BLOCK_COLUMNS_192_192{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_192_192];
            }
        }
        //mix_columns
        for c in 0..constants::BLOCK_COLUMNS_192_192{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_FORWARD[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_FORWARD[r][i]);
                }
            }
        }
        //add round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_192{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
    }
    //substitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_192{
            local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
        }
    }
    //rotate rows
    for r in 1..4{
            let shift : usize = constants::SHIFTS_192_192[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_192_192-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_192_192-shift)..constants::BLOCK_COLUMNS_192_192{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_192_192];
            }
    }
    //add final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_192{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_192_192-1][r][c];
        }
    }
    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_192_192{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


pub fn decrypt_block_192_192(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_192_192];4];constants::ROUNDS_192_192],
input_block : & [u8;constants::BLOCK_BYTES_192_192],
destination_block : &mut [u8;constants::BLOCK_BYTES_192_192]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_192_192];4] = [[0;constants::BLOCK_COLUMNS_192_192];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_192_192];4];constants::ROUNDS_192_192] =
								[[[0;constants::BLOCK_COLUMNS_192_192];4];constants::ROUNDS_192_192];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_192_192{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_192{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_192_192{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }

    //minus final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_192{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_192_192-1][r][c];
        }
    }

    //unrotate_rows
    for r in 1..4{
        let shift : usize = constants::SHIFTS_192_192[r];
        for i in (constants::BLOCK_COLUMNS_192_192-shift)..constants::BLOCK_COLUMNS_192_192{
            buffer[i+shift-constants::BLOCK_COLUMNS_192_192] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_192_192).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
    }

    //unsubstitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_192{
            local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
        }
    }

    for round in (1..(constants::ROUNDS_192_192-1)).rev(){
        //minus round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_192{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
        //unmix_columns
        for c in 0..constants::BLOCK_COLUMNS_192_192{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_REVERSE[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_REVERSE[r][i]);
                }
            }
        }

        //unrotate_rows
        for r in 1..4{
        let shift : usize = constants::SHIFTS_192_192[r];
        for i in (constants::BLOCK_COLUMNS_192_192-shift)..constants::BLOCK_COLUMNS_192_192{
            buffer[i+shift-constants::BLOCK_COLUMNS_192_192] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_192_192).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
        }

        //unsubstitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_192{
                local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
            }
        }


    }

    //minus round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_192{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }

    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_192_192{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}
/***************************************************************************************************
 * function name:  expand_key_(KEY_SIZE)_(BLOCK_SIZE)
 *
 * function:       (self explanatory)
 *
 * arguments:      expanded_key = the expanded key to use
 *                 key = raw key bits
 *
 * return:         void
 *
 * notes:          (none)
 **************************************************************************************************/


pub fn print_key_expansion_192_160(expanded_key : & [[[u8;constants::BLOCK_COLUMNS_192_160];4];constants::ROUNDS_192_160]){
    for i in 0..constants::ROUNDS_192_160{
        for c in 0..constants::BLOCK_COLUMNS_192_160{
            for r in 0..4{
                print!("{:02X} ",expanded_key[i][r][c]);
            }
        }
        println!();
    }
    println!();
}


fn print_block_192_160(message : &str, block : &[[u8;constants::BLOCK_COLUMNS_192_160];4]){
    println!("{}", message);
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_160{
            print!("{:02X} ", block[r][c]);
        }
        println!();
    }
    println!();
}

fn combo_move_192_160(temp :&mut  [[u8;constants::KEY_COLUMNS_192_160];4], round_constant_index : usize){
    for r in 0..4{
        temp[r][0] ^= constants::SBOX_FORWARD[temp[(r+1)%4][constants::KEY_COLUMNS_192_160-1] as usize];
    }
    temp[0][0] ^= constants::ROUND_CONSTANTS[round_constant_index];
}
fn swoosh_move_192_160(temp  : &mut [[u8;constants::KEY_COLUMNS_192_160];4] ){
    /*
    if constants::KEY_COLUMNS_192_160 < 6{
    */
        for c in 1..constants::KEY_COLUMNS_192_160{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    /*
    } else {

        for c in 1..4{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
        for r in 0..4{
            temp[r][4] ^= constants::SBOX_FORWARD[(temp[r][3])as usize];
        }
        for c in 5..constants::KEY_COLUMNS_192_160{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }

    }
    */
}
fn load_move_192_160(temp : &[[u8;constants::KEY_COLUMNS_192_160];4],
expand_key : &mut [[[u8;constants::BLOCK_COLUMNS_192_160];4];constants::ROUNDS_192_160],
loads : usize,
expand_key_counter : &mut Counter){
    for c in 0..loads{
        for r in 0..4{
            expand_key[expand_key_counter.i][expand_key_counter.r][expand_key_counter.c]=temp[r][c];
            expand_key_counter.increment();
        }
    }
}

pub fn expand_key_192_160(key : &[u8;constants::KEY_BYTES_192_160],
expanded_key : &mut [[[u8;constants::BLOCK_COLUMNS_192_160];4];constants::ROUNDS_192_160]){
    //load into a local variable
    let mut round_constant_index : usize = 0;
    let mut temp : [[u8;constants::KEY_COLUMNS_192_160];4] =[[0;constants::KEY_COLUMNS_192_160];4];
    let mut expand_key_counter : Counter = Counter::new(constants::ROUNDS_192_160, constants::BLOCK_COLUMNS_192_160);
	let total_columns_needed : usize = constants::ROUNDS_192_160*constants::BLOCK_COLUMNS_192_160-constants::KEY_COLUMNS_192_160;
    let key_expansion_rounds_needed :usize = total_columns_needed/constants::KEY_COLUMNS_192_160;
    let key_expansion_remainder : usize = total_columns_needed%constants::KEY_COLUMNS_192_160;

    //load key into temporary matrix
    for c in 0..constants::KEY_COLUMNS_192_160{
        for r in 0..4{
            temp[r][c] = key[round_constant_index];
            round_constant_index+=1;
        }
    }
    //move temp into expanded key
    load_move_192_160(&temp, expanded_key, constants::KEY_COLUMNS_192_160, &mut expand_key_counter);
    //processing different for each type
    for round_constant_index in 1..key_expansion_rounds_needed+1{
        combo_move_192_160(&mut temp, round_constant_index);
        swoosh_move_192_160(&mut temp);
        load_move_192_160(&temp, expanded_key, constants::KEY_COLUMNS_192_160, &mut expand_key_counter);
    }
    if key_expansion_remainder > 0{
        combo_move_192_160(&mut temp, key_expansion_rounds_needed+1);
        swoosh_move_192_160(&mut temp);
        load_move_192_160(&temp, expanded_key, key_expansion_remainder, &mut expand_key_counter);
    }

}

pub fn encrypt_block_192_160(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_192_160];4];constants::ROUNDS_192_160],
input_block : & [u8;constants::BLOCK_BYTES_192_160],
destination_block : &mut [u8;constants::BLOCK_BYTES_192_160]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_192_160];4] = [[0;constants::BLOCK_COLUMNS_192_160];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_192_160];4];constants::ROUNDS_192_160] =
								[[[0;constants::BLOCK_COLUMNS_192_160];4];constants::ROUNDS_192_160];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_192_160{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_160{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_192_160{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }
    //add round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_160{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }
    //PROCESS ROUNDS
    for round in 1..(constants::ROUNDS_192_160-1){
        //substitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_160{
                local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
            }
        }

        //rotate rows
        for r in 1..4{
            let shift : usize = constants::SHIFTS_192_160[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_192_160-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_192_160-shift)..constants::BLOCK_COLUMNS_192_160{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_192_160];
            }
        }
        //mix_columns
        for c in 0..constants::BLOCK_COLUMNS_192_160{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_FORWARD[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_FORWARD[r][i]);
                }
            }
        }
        //add round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_160{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
    }
    //substitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_160{
            local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
        }
    }
    //rotate rows
    for r in 1..4{
            let shift : usize = constants::SHIFTS_192_160[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_192_160-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_192_160-shift)..constants::BLOCK_COLUMNS_192_160{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_192_160];
            }
    }
    //add final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_160{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_192_160-1][r][c];
        }
    }
    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_192_160{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


pub fn decrypt_block_192_160(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_192_160];4];constants::ROUNDS_192_160],
input_block : & [u8;constants::BLOCK_BYTES_192_160],
destination_block : &mut [u8;constants::BLOCK_BYTES_192_160]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_192_160];4] = [[0;constants::BLOCK_COLUMNS_192_160];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_192_160];4];constants::ROUNDS_192_160] =
								[[[0;constants::BLOCK_COLUMNS_192_160];4];constants::ROUNDS_192_160];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_192_160{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_160{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_192_160{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }

    //minus final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_160{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_192_160-1][r][c];
        }
    }

    //unrotate_rows
    for r in 1..4{
        let shift : usize = constants::SHIFTS_192_160[r];
        for i in (constants::BLOCK_COLUMNS_192_160-shift)..constants::BLOCK_COLUMNS_192_160{
            buffer[i+shift-constants::BLOCK_COLUMNS_192_160] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_192_160).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
    }

    //unsubstitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_160{
            local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
        }
    }

    for round in (1..(constants::ROUNDS_192_160-1)).rev(){
        //minus round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_160{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
        //unmix_columns
        for c in 0..constants::BLOCK_COLUMNS_192_160{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_REVERSE[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_REVERSE[r][i]);
                }
            }
        }

        //unrotate_rows
        for r in 1..4{
        let shift : usize = constants::SHIFTS_192_160[r];
        for i in (constants::BLOCK_COLUMNS_192_160-shift)..constants::BLOCK_COLUMNS_192_160{
            buffer[i+shift-constants::BLOCK_COLUMNS_192_160] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_192_160).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
        }

        //unsubstitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_160{
                local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
            }
        }


    }

    //minus round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_160{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }

    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_192_160{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}

/***************************************************************************************************
 * function name:  expand_key_(KEY_SIZE)_(BLOCK_SIZE)
 *
 * function:       (self explanatory)
 *
 * arguments:      expanded_key = the expanded key to use
 *                 key = raw key bits
 *
 * return:         void
 *
 * notes:          (none)
 **************************************************************************************************/


pub fn print_key_expansion_192_224(expanded_key : & [[[u8;constants::BLOCK_COLUMNS_192_224];4];constants::ROUNDS_192_224]){
    for i in 0..constants::ROUNDS_192_224{
        for c in 0..constants::BLOCK_COLUMNS_192_224{
            for r in 0..4{
                print!("{:02X} ",expanded_key[i][r][c]);
            }
        }
        println!();
    }
    println!();
}


fn print_block_192_224(message : &str, block : &[[u8;constants::BLOCK_COLUMNS_192_224];4]){
    println!("{}", message);
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_224{
            print!("{:02X} ", block[r][c]);
        }
        println!();
    }
    println!();
}

fn combo_move_192_224(temp :&mut  [[u8;constants::KEY_COLUMNS_192_224];4], round_constant_index : usize){
    for r in 0..4{
        temp[r][0] ^= constants::SBOX_FORWARD[temp[(r+1)%4][constants::KEY_COLUMNS_192_224-1] as usize];
    }
    temp[0][0] ^= constants::ROUND_CONSTANTS[round_constant_index];
}
fn swoosh_move_192_224(temp  : &mut [[u8;constants::KEY_COLUMNS_192_224];4] ){
    /*
    if constants::KEY_COLUMNS_192_224 < 6{
    */
        for c in 1..constants::KEY_COLUMNS_192_224{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    /*
    } else {

        for c in 1..4{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
        for r in 0..4{
            temp[r][4] ^= constants::SBOX_FORWARD[(temp[r][3])as usize];
        }
        for c in 5..constants::KEY_COLUMNS_192_224{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }

    }
    */
}
fn load_move_192_224(temp : &[[u8;constants::KEY_COLUMNS_192_224];4],
expand_key : &mut [[[u8;constants::BLOCK_COLUMNS_192_224];4];constants::ROUNDS_192_224],
loads : usize,
expand_key_counter : &mut Counter){
    for c in 0..loads{
        for r in 0..4{
            expand_key[expand_key_counter.i][expand_key_counter.r][expand_key_counter.c]=temp[r][c];
            expand_key_counter.increment();
        }
    }
}

pub fn expand_key_192_224(key : &[u8;constants::KEY_BYTES_192_224],
expanded_key : &mut [[[u8;constants::BLOCK_COLUMNS_192_224];4];constants::ROUNDS_192_224]){
    //load into a local variable
    let mut round_constant_index : usize = 0;
    let mut temp : [[u8;constants::KEY_COLUMNS_192_224];4] =[[0;constants::KEY_COLUMNS_192_224];4];
    let mut expand_key_counter : Counter = Counter::new(constants::ROUNDS_192_224, constants::BLOCK_COLUMNS_192_224);
	let total_columns_needed : usize = constants::ROUNDS_192_224*constants::BLOCK_COLUMNS_192_224-constants::KEY_COLUMNS_192_224;
    let key_expansion_rounds_needed :usize = total_columns_needed/constants::KEY_COLUMNS_192_224;
    let key_expansion_remainder : usize = total_columns_needed%constants::KEY_COLUMNS_192_224;

    //load key into temporary matrix
    for c in 0..constants::KEY_COLUMNS_192_224{
        for r in 0..4{
            temp[r][c] = key[round_constant_index];
            round_constant_index+=1;
        }
    }
    //move temp into expanded key
    load_move_192_224(&temp, expanded_key, constants::KEY_COLUMNS_192_224, &mut expand_key_counter);
    //processing different for each type
    for round_constant_index in 1..key_expansion_rounds_needed+1{
        combo_move_192_224(&mut temp, round_constant_index);
        swoosh_move_192_224(&mut temp);
        load_move_192_224(&temp, expanded_key, constants::KEY_COLUMNS_192_224, &mut expand_key_counter);
    }
    if key_expansion_remainder > 0{
        combo_move_192_224(&mut temp, key_expansion_rounds_needed+1);
        swoosh_move_192_224(&mut temp);
        load_move_192_224(&temp, expanded_key, key_expansion_remainder, &mut expand_key_counter);
    }

}

pub fn encrypt_block_192_224(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_192_224];4];constants::ROUNDS_192_224],
input_block : & [u8;constants::BLOCK_BYTES_192_224],
destination_block : &mut [u8;constants::BLOCK_BYTES_192_224]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_192_224];4] = [[0;constants::BLOCK_COLUMNS_192_224];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_192_224];4];constants::ROUNDS_192_224] =
								[[[0;constants::BLOCK_COLUMNS_192_224];4];constants::ROUNDS_192_224];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_192_224{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_224{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_192_224{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }
    //add round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_224{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }
    //PROCESS ROUNDS
    for round in 1..(constants::ROUNDS_192_224-1){
        //substitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_224{
                local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
            }
        }

        //rotate rows
        for r in 1..4{
            let shift : usize = constants::SHIFTS_192_224[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_192_224-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_192_224-shift)..constants::BLOCK_COLUMNS_192_224{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_192_224];
            }
        }
        //mix_columns
        for c in 0..constants::BLOCK_COLUMNS_192_224{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_FORWARD[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_FORWARD[r][i]);
                }
            }
        }
        //add round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_224{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
    }
    //substitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_224{
            local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
        }
    }
    //rotate rows
    for r in 1..4{
            let shift : usize = constants::SHIFTS_192_224[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_192_224-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_192_224-shift)..constants::BLOCK_COLUMNS_192_224{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_192_224];
            }
    }
    //add final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_224{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_192_224-1][r][c];
        }
    }
    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_192_224{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


pub fn decrypt_block_192_224(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_192_224];4];constants::ROUNDS_192_224],
input_block : & [u8;constants::BLOCK_BYTES_192_224],
destination_block : &mut [u8;constants::BLOCK_BYTES_192_224]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_192_224];4] = [[0;constants::BLOCK_COLUMNS_192_224];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_192_224];4];constants::ROUNDS_192_224] =
								[[[0;constants::BLOCK_COLUMNS_192_224];4];constants::ROUNDS_192_224];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_192_224{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_224{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_192_224{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }

    //minus final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_224{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_192_224-1][r][c];
        }
    }

    //unrotate_rows
    for r in 1..4{
        let shift : usize = constants::SHIFTS_192_224[r];
        for i in (constants::BLOCK_COLUMNS_192_224-shift)..constants::BLOCK_COLUMNS_192_224{
            buffer[i+shift-constants::BLOCK_COLUMNS_192_224] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_192_224).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
    }

    //unsubstitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_224{
            local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
        }
    }

    for round in (1..(constants::ROUNDS_192_224-1)).rev(){
        //minus round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_224{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
        //unmix_columns
        for c in 0..constants::BLOCK_COLUMNS_192_224{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_REVERSE[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_REVERSE[r][i]);
                }
            }
        }

        //unrotate_rows
        for r in 1..4{
        let shift : usize = constants::SHIFTS_192_224[r];
        for i in (constants::BLOCK_COLUMNS_192_224-shift)..constants::BLOCK_COLUMNS_192_224{
            buffer[i+shift-constants::BLOCK_COLUMNS_192_224] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_192_224).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
        }

        //unsubstitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_224{
                local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
            }
        }


    }

    //minus round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_224{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }

    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_192_224{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}

/***************************************************************************************************
 * function name:  expand_key_(KEY_SIZE)_(BLOCK_SIZE)
 *
 * function:       (self explanatory)
 *
 * arguments:      expanded_key = the expanded key to use
 *                 key = raw key bits
 *
 * return:         void
 *
 * notes:          (none)
 **************************************************************************************************/


pub fn print_key_expansion_192_256(expanded_key : & [[[u8;constants::BLOCK_COLUMNS_192_256];4];constants::ROUNDS_192_256]){
    for i in 0..constants::ROUNDS_192_256{
        for c in 0..constants::BLOCK_COLUMNS_192_256{
            for r in 0..4{
                print!("{:02X} ",expanded_key[i][r][c]);
            }
        }
        println!();
    }
    println!();
}


fn print_block_192_256(message : &str, block : &[[u8;constants::BLOCK_COLUMNS_192_256];4]){
    println!("{}", message);
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_256{
            print!("{:02X} ", block[r][c]);
        }
        println!();
    }
    println!();
}

fn combo_move_192_256(temp :&mut  [[u8;constants::KEY_COLUMNS_192_256];4], round_constant_index : usize){
    for r in 0..4{
        temp[r][0] ^= constants::SBOX_FORWARD[temp[(r+1)%4][constants::KEY_COLUMNS_192_256-1] as usize];
    }
    temp[0][0] ^= constants::ROUND_CONSTANTS[round_constant_index];
}
fn swoosh_move_192_256(temp  : &mut [[u8;constants::KEY_COLUMNS_192_256];4] ){
    /*
    if constants::KEY_COLUMNS_192_256 < 6{
    */
        for c in 1..constants::KEY_COLUMNS_192_256{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    /*
    } else {

        for c in 1..4{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
        for r in 0..4{
            temp[r][4] ^= constants::SBOX_FORWARD[(temp[r][3])as usize];
        }
        for c in 5..constants::KEY_COLUMNS_192_256{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }

    }
    */
}
fn load_move_192_256(temp : &[[u8;constants::KEY_COLUMNS_192_256];4],
expand_key : &mut [[[u8;constants::BLOCK_COLUMNS_192_256];4];constants::ROUNDS_192_256],
loads : usize,
expand_key_counter : &mut Counter){
    for c in 0..loads{
        for r in 0..4{
            expand_key[expand_key_counter.i][expand_key_counter.r][expand_key_counter.c]=temp[r][c];
            expand_key_counter.increment();
        }
    }
}

pub fn expand_key_192_256(key : &[u8;constants::KEY_BYTES_192_256],
expanded_key : &mut [[[u8;constants::BLOCK_COLUMNS_192_256];4];constants::ROUNDS_192_256]){
    //load into a local variable
    let mut round_constant_index : usize = 0;
    let mut temp : [[u8;constants::KEY_COLUMNS_192_256];4] =[[0;constants::KEY_COLUMNS_192_256];4];
    let mut expand_key_counter : Counter = Counter::new(constants::ROUNDS_192_256, constants::BLOCK_COLUMNS_192_256);
	let total_columns_needed : usize = constants::ROUNDS_192_256*constants::BLOCK_COLUMNS_192_256-constants::KEY_COLUMNS_192_256;
    let key_expansion_rounds_needed :usize = total_columns_needed/constants::KEY_COLUMNS_192_256;
    let key_expansion_remainder : usize = total_columns_needed%constants::KEY_COLUMNS_192_256;

    //load key into temporary matrix
    for c in 0..constants::KEY_COLUMNS_192_256{
        for r in 0..4{
            temp[r][c] = key[round_constant_index];
            round_constant_index+=1;
        }
    }
    //move temp into expanded key
    load_move_192_256(&temp, expanded_key, constants::KEY_COLUMNS_192_256, &mut expand_key_counter);
    //processing different for each type
    for round_constant_index in 1..key_expansion_rounds_needed+1{
        combo_move_192_256(&mut temp, round_constant_index);
        swoosh_move_192_256(&mut temp);
        load_move_192_256(&temp, expanded_key, constants::KEY_COLUMNS_192_256, &mut expand_key_counter);
    }
    if key_expansion_remainder > 0{
        combo_move_192_256(&mut temp, key_expansion_rounds_needed+1);
        swoosh_move_192_256(&mut temp);
        load_move_192_256(&temp, expanded_key, key_expansion_remainder, &mut expand_key_counter);
    }

}

pub fn encrypt_block_192_256(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_192_256];4];constants::ROUNDS_192_256],
input_block : & [u8;constants::BLOCK_BYTES_192_256],
destination_block : &mut [u8;constants::BLOCK_BYTES_192_256]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_192_256];4] = [[0;constants::BLOCK_COLUMNS_192_256];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_192_256];4];constants::ROUNDS_192_256] =
								[[[0;constants::BLOCK_COLUMNS_192_256];4];constants::ROUNDS_192_256];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_192_256{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_256{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_192_256{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }
    //add round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_256{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }
    //PROCESS ROUNDS
    for round in 1..(constants::ROUNDS_192_256-1){
        //substitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_256{
                local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
            }
        }

        //rotate rows
        for r in 1..4{
            let shift : usize = constants::SHIFTS_192_256[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_192_256-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_192_256-shift)..constants::BLOCK_COLUMNS_192_256{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_192_256];
            }
        }
        //mix_columns
        for c in 0..constants::BLOCK_COLUMNS_192_256{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_FORWARD[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_FORWARD[r][i]);
                }
            }
        }
        //add round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_256{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
    }
    //substitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_256{
            local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
        }
    }
    //rotate rows
    for r in 1..4{
            let shift : usize = constants::SHIFTS_192_256[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_192_256-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_192_256-shift)..constants::BLOCK_COLUMNS_192_256{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_192_256];
            }
    }
    //add final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_256{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_192_256-1][r][c];
        }
    }
    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_192_256{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


pub fn decrypt_block_192_256(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_192_256];4];constants::ROUNDS_192_256],
input_block : & [u8;constants::BLOCK_BYTES_192_256],
destination_block : &mut [u8;constants::BLOCK_BYTES_192_256]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_192_256];4] = [[0;constants::BLOCK_COLUMNS_192_256];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_192_256];4];constants::ROUNDS_192_256] =
								[[[0;constants::BLOCK_COLUMNS_192_256];4];constants::ROUNDS_192_256];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_192_256{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_256{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_192_256{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }

    //minus final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_256{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_192_256-1][r][c];
        }
    }

    //unrotate_rows
    for r in 1..4{
        let shift : usize = constants::SHIFTS_192_256[r];
        for i in (constants::BLOCK_COLUMNS_192_256-shift)..constants::BLOCK_COLUMNS_192_256{
            buffer[i+shift-constants::BLOCK_COLUMNS_192_256] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_192_256).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
    }

    //unsubstitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_256{
            local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
        }
    }

    for round in (1..(constants::ROUNDS_192_256-1)).rev(){
        //minus round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_256{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
        //unmix_columns
        for c in 0..constants::BLOCK_COLUMNS_192_256{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_REVERSE[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_REVERSE[r][i]);
                }
            }
        }

        //unrotate_rows
        for r in 1..4{
        let shift : usize = constants::SHIFTS_192_256[r];
        for i in (constants::BLOCK_COLUMNS_192_256-shift)..constants::BLOCK_COLUMNS_192_256{
            buffer[i+shift-constants::BLOCK_COLUMNS_192_256] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_192_256).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
        }

        //unsubstitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_192_256{
                local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
            }
        }


    }

    //minus round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_192_256{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }

    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_192_256{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}

/***************************************************************************************************
 * function name:  expand_key_(KEY_SIZE)_(BLOCK_SIZE)
 *
 * function:       (self explanatory)
 *
 * arguments:      expanded_key = the expanded key to use
 *                 key = raw key bits
 *
 * return:         void
 *
 * notes:          (none)
 **************************************************************************************************/


pub fn print_key_expansion_224_128(expanded_key : & [[[u8;constants::BLOCK_COLUMNS_224_128];4];constants::ROUNDS_224_128]){
    for i in 0..constants::ROUNDS_224_128{
        for c in 0..constants::BLOCK_COLUMNS_224_128{
            for r in 0..4{
                print!("{:02X} ",expanded_key[i][r][c]);
            }
        }
        println!();
    }
    println!();
}


fn print_block_224_128(message : &str, block : &[[u8;constants::BLOCK_COLUMNS_224_128];4]){
    println!("{}", message);
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_128{
            print!("{:02X} ", block[r][c]);
        }
        println!();
    }
    println!();
}

fn combo_move_224_128(temp :&mut  [[u8;constants::KEY_COLUMNS_224_128];4], round_constant_index : usize){
    for r in 0..4{
        temp[r][0] ^= constants::SBOX_FORWARD[temp[(r+1)%4][constants::KEY_COLUMNS_224_128-1] as usize];
    }
    temp[0][0] ^= constants::ROUND_CONSTANTS[round_constant_index];
}
fn swoosh_move_224_128(temp  : &mut [[u8;constants::KEY_COLUMNS_224_128];4] ){
    /*
    if constants::KEY_COLUMNS_224_128 < 6{

        for c in 1..constants::KEY_COLUMNS_224_128{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }

    } else {
    */
        for c in 1..4{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
        for r in 0..4{
            temp[r][4] ^= constants::SBOX_FORWARD[(temp[r][3])as usize];
        }
        for c in 5..constants::KEY_COLUMNS_224_128{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    /*
    }
    */
}
fn load_move_224_128(temp : &[[u8;constants::KEY_COLUMNS_224_128];4],
expand_key : &mut [[[u8;constants::BLOCK_COLUMNS_224_128];4];constants::ROUNDS_224_128],
loads : usize,
expand_key_counter : &mut Counter){
    for c in 0..loads{
        for r in 0..4{
            expand_key[expand_key_counter.i][expand_key_counter.r][expand_key_counter.c]=temp[r][c];
            expand_key_counter.increment();
        }
    }
}

pub fn expand_key_224_128(key : &[u8;constants::KEY_BYTES_224_128],
expanded_key : &mut [[[u8;constants::BLOCK_COLUMNS_224_128];4];constants::ROUNDS_224_128]){
    //load into a local variable
    let mut round_constant_index : usize = 0;
    let mut temp : [[u8;constants::KEY_COLUMNS_224_128];4] =[[0;constants::KEY_COLUMNS_224_128];4];
    let mut expand_key_counter : Counter = Counter::new(constants::ROUNDS_224_128, constants::BLOCK_COLUMNS_224_128);
	let total_columns_needed : usize = constants::ROUNDS_224_128*constants::BLOCK_COLUMNS_224_128-constants::KEY_COLUMNS_224_128;
    let key_expansion_rounds_needed :usize = total_columns_needed/constants::KEY_COLUMNS_224_128;
    let key_expansion_remainder : usize = total_columns_needed%constants::KEY_COLUMNS_224_128;

    //load key into temporary matrix
    for c in 0..constants::KEY_COLUMNS_224_128{
        for r in 0..4{
            temp[r][c] = key[round_constant_index];
            round_constant_index+=1;
        }
    }
    //move temp into expanded key
    load_move_224_128(&temp, expanded_key, constants::KEY_COLUMNS_224_128, &mut expand_key_counter);
    //processing different for each type
    for round_constant_index in 1..key_expansion_rounds_needed+1{
        combo_move_224_128(&mut temp, round_constant_index);
        swoosh_move_224_128(&mut temp);
        load_move_224_128(&temp, expanded_key, constants::KEY_COLUMNS_224_128, &mut expand_key_counter);
    }
    if key_expansion_remainder > 0{
        combo_move_224_128(&mut temp, key_expansion_rounds_needed+1);
        swoosh_move_224_128(&mut temp);
        load_move_224_128(&temp, expanded_key, key_expansion_remainder, &mut expand_key_counter);
    }

}

pub fn encrypt_block_224_128(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_224_128];4];constants::ROUNDS_224_128],
input_block : & [u8;constants::BLOCK_BYTES_224_128],
destination_block : &mut [u8;constants::BLOCK_BYTES_224_128]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_224_128];4] = [[0;constants::BLOCK_COLUMNS_224_128];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_224_128];4];constants::ROUNDS_224_128] =
								[[[0;constants::BLOCK_COLUMNS_224_128];4];constants::ROUNDS_224_128];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_224_128{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_128{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_224_128{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }
    //add round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_128{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }
    //PROCESS ROUNDS
    for round in 1..(constants::ROUNDS_224_128-1){
        //substitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_128{
                local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
            }
        }

        //rotate rows
        for r in 1..4{
            let shift : usize = constants::SHIFTS_224_128[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_224_128-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_224_128-shift)..constants::BLOCK_COLUMNS_224_128{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_224_128];
            }
        }
        //mix_columns
        for c in 0..constants::BLOCK_COLUMNS_224_128{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_FORWARD[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_FORWARD[r][i]);
                }
            }
        }
        //add round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_128{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
    }
    //substitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_128{
            local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
        }
    }
    //rotate rows
    for r in 1..4{
            let shift : usize = constants::SHIFTS_224_128[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_224_128-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_224_128-shift)..constants::BLOCK_COLUMNS_224_128{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_224_128];
            }
    }
    //add final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_128{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_224_128-1][r][c];
        }
    }
    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_224_128{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


pub fn decrypt_block_224_128(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_224_128];4];constants::ROUNDS_224_128],
input_block : & [u8;constants::BLOCK_BYTES_224_128],
destination_block : &mut [u8;constants::BLOCK_BYTES_224_128]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_224_128];4] = [[0;constants::BLOCK_COLUMNS_224_128];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_224_128];4];constants::ROUNDS_224_128] =
								[[[0;constants::BLOCK_COLUMNS_224_128];4];constants::ROUNDS_224_128];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_224_128{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_128{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_224_128{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }

    //minus final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_128{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_224_128-1][r][c];
        }
    }

    //unrotate_rows
    for r in 1..4{
        let shift : usize = constants::SHIFTS_224_128[r];
        for i in (constants::BLOCK_COLUMNS_224_128-shift)..constants::BLOCK_COLUMNS_224_128{
            buffer[i+shift-constants::BLOCK_COLUMNS_224_128] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_224_128).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
    }

    //unsubstitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_128{
            local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
        }
    }

    for round in (1..(constants::ROUNDS_224_128-1)).rev(){
        //minus round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_128{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
        //unmix_columns
        for c in 0..constants::BLOCK_COLUMNS_224_128{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_REVERSE[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_REVERSE[r][i]);
                }
            }
        }

        //unrotate_rows
        for r in 1..4{
        let shift : usize = constants::SHIFTS_224_128[r];
        for i in (constants::BLOCK_COLUMNS_224_128-shift)..constants::BLOCK_COLUMNS_224_128{
            buffer[i+shift-constants::BLOCK_COLUMNS_224_128] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_224_128).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
        }

        //unsubstitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_128{
                local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
            }
        }


    }

    //minus round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_128{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }

    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_224_128{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}

/***************************************************************************************************
 * function name:  expand_key_(KEY_SIZE)_(BLOCK_SIZE)
 *
 * function:       (self explanatory)
 *
 * arguments:      expanded_key = the expanded key to use
 *                 key = raw key bits
 *
 * return:         void
 *
 * notes:          (none)
 **************************************************************************************************/


pub fn print_key_expansion_224_160(expanded_key : & [[[u8;constants::BLOCK_COLUMNS_224_160];4];constants::ROUNDS_224_160]){
    for i in 0..constants::ROUNDS_224_160{
        for c in 0..constants::BLOCK_COLUMNS_224_160{
            for r in 0..4{
                print!("{:02X} ",expanded_key[i][r][c]);
            }
        }
        println!();
    }
    println!();
}


fn print_block_224_160(message : &str, block : &[[u8;constants::BLOCK_COLUMNS_224_160];4]){
    println!("{}", message);
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_160{
            print!("{:02X} ", block[r][c]);
        }
        println!();
    }
    println!();
}

fn combo_move_224_160(temp :&mut  [[u8;constants::KEY_COLUMNS_224_160];4], round_constant_index : usize){
    for r in 0..4{
        temp[r][0] ^= constants::SBOX_FORWARD[temp[(r+1)%4][constants::KEY_COLUMNS_224_160-1] as usize];
    }
    temp[0][0] ^= constants::ROUND_CONSTANTS[round_constant_index];
}
fn swoosh_move_224_160(temp  : &mut [[u8;constants::KEY_COLUMNS_224_160];4] ){
    /*
    if constants::KEY_COLUMNS_224_160 < 6{

        for c in 1..constants::KEY_COLUMNS_224_160{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }

    } else {
    */
        for c in 1..4{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
        for r in 0..4{
            temp[r][4] ^= constants::SBOX_FORWARD[(temp[r][3])as usize];
        }
        for c in 5..constants::KEY_COLUMNS_224_160{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    /*
    }
    */
}
fn load_move_224_160(temp : &[[u8;constants::KEY_COLUMNS_224_160];4],
expand_key : &mut [[[u8;constants::BLOCK_COLUMNS_224_160];4];constants::ROUNDS_224_160],
loads : usize,
expand_key_counter : &mut Counter){
    for c in 0..loads{
        for r in 0..4{
            expand_key[expand_key_counter.i][expand_key_counter.r][expand_key_counter.c]=temp[r][c];
            expand_key_counter.increment();
        }
    }
}

pub fn expand_key_224_160(key : &[u8;constants::KEY_BYTES_224_160],
expanded_key : &mut [[[u8;constants::BLOCK_COLUMNS_224_160];4];constants::ROUNDS_224_160]){
    //load into a local variable
    let mut round_constant_index : usize = 0;
    let mut temp : [[u8;constants::KEY_COLUMNS_224_160];4] =[[0;constants::KEY_COLUMNS_224_160];4];
    let mut expand_key_counter : Counter = Counter::new(constants::ROUNDS_224_160, constants::BLOCK_COLUMNS_224_160);
	let total_columns_needed : usize = constants::ROUNDS_224_160*constants::BLOCK_COLUMNS_224_160-constants::KEY_COLUMNS_224_160;
    let key_expansion_rounds_needed :usize = total_columns_needed/constants::KEY_COLUMNS_224_160;
    let key_expansion_remainder : usize = total_columns_needed%constants::KEY_COLUMNS_224_160;

    //load key into temporary matrix
    for c in 0..constants::KEY_COLUMNS_224_160{
        for r in 0..4{
            temp[r][c] = key[round_constant_index];
            round_constant_index+=1;
        }
    }
    //move temp into expanded key
    load_move_224_160(&temp, expanded_key, constants::KEY_COLUMNS_224_160, &mut expand_key_counter);
    //processing different for each type
    for round_constant_index in 1..key_expansion_rounds_needed+1{
        combo_move_224_160(&mut temp, round_constant_index);
        swoosh_move_224_160(&mut temp);
        load_move_224_160(&temp, expanded_key, constants::KEY_COLUMNS_224_160, &mut expand_key_counter);
    }
    if key_expansion_remainder > 0{
        combo_move_224_160(&mut temp, key_expansion_rounds_needed+1);
        swoosh_move_224_160(&mut temp);
        load_move_224_160(&temp, expanded_key, key_expansion_remainder, &mut expand_key_counter);
    }

}

pub fn encrypt_block_224_160(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_224_160];4];constants::ROUNDS_224_160],
input_block : & [u8;constants::BLOCK_BYTES_224_160],
destination_block : &mut [u8;constants::BLOCK_BYTES_224_160]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_224_160];4] = [[0;constants::BLOCK_COLUMNS_224_160];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_224_160];4];constants::ROUNDS_224_160] =
								[[[0;constants::BLOCK_COLUMNS_224_160];4];constants::ROUNDS_224_160];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_224_160{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_160{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_224_160{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }
    //add round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_160{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }
    //PROCESS ROUNDS
    for round in 1..(constants::ROUNDS_224_160-1){
        //substitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_160{
                local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
            }
        }

        //rotate rows
        for r in 1..4{
            let shift : usize = constants::SHIFTS_224_160[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_224_160-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_224_160-shift)..constants::BLOCK_COLUMNS_224_160{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_224_160];
            }
        }
        //mix_columns
        for c in 0..constants::BLOCK_COLUMNS_224_160{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_FORWARD[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_FORWARD[r][i]);
                }
            }
        }
        //add round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_160{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
    }
    //substitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_160{
            local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
        }
    }
    //rotate rows
    for r in 1..4{
            let shift : usize = constants::SHIFTS_224_160[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_224_160-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_224_160-shift)..constants::BLOCK_COLUMNS_224_160{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_224_160];
            }
    }
    //add final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_160{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_224_160-1][r][c];
        }
    }
    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_224_160{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


pub fn decrypt_block_224_160(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_224_160];4];constants::ROUNDS_224_160],
input_block : & [u8;constants::BLOCK_BYTES_224_160],
destination_block : &mut [u8;constants::BLOCK_BYTES_224_160]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_224_160];4] = [[0;constants::BLOCK_COLUMNS_224_160];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_224_160];4];constants::ROUNDS_224_160] =
								[[[0;constants::BLOCK_COLUMNS_224_160];4];constants::ROUNDS_224_160];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_224_160{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_160{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_224_160{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }

    //minus final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_160{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_224_160-1][r][c];
        }
    }

    //unrotate_rows
    for r in 1..4{
        let shift : usize = constants::SHIFTS_224_160[r];
        for i in (constants::BLOCK_COLUMNS_224_160-shift)..constants::BLOCK_COLUMNS_224_160{
            buffer[i+shift-constants::BLOCK_COLUMNS_224_160] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_224_160).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
    }

    //unsubstitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_160{
            local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
        }
    }

    for round in (1..(constants::ROUNDS_224_160-1)).rev(){
        //minus round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_160{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
        //unmix_columns
        for c in 0..constants::BLOCK_COLUMNS_224_160{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_REVERSE[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_REVERSE[r][i]);
                }
            }
        }

        //unrotate_rows
        for r in 1..4{
        let shift : usize = constants::SHIFTS_224_160[r];
        for i in (constants::BLOCK_COLUMNS_224_160-shift)..constants::BLOCK_COLUMNS_224_160{
            buffer[i+shift-constants::BLOCK_COLUMNS_224_160] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_224_160).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
        }

        //unsubstitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_160{
                local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
            }
        }


    }

    //minus round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_160{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }

    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_224_160{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}

/***************************************************************************************************
 * function name:  expand_key_(KEY_SIZE)_(BLOCK_SIZE)
 *
 * function:       (self explanatory)
 *
 * arguments:      expanded_key = the expanded key to use
 *                 key = raw key bits
 *
 * return:         void
 *
 * notes:          (none)
 **************************************************************************************************/


pub fn print_key_expansion_224_192(expanded_key : & [[[u8;constants::BLOCK_COLUMNS_224_192];4];constants::ROUNDS_224_192]){
    for i in 0..constants::ROUNDS_224_192{
        for c in 0..constants::BLOCK_COLUMNS_224_192{
            for r in 0..4{
                print!("{:02X} ",expanded_key[i][r][c]);
            }
        }
        println!();
    }
    println!();
}


fn print_block_224_192(message : &str, block : &[[u8;constants::BLOCK_COLUMNS_224_192];4]){
    println!("{}", message);
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_192{
            print!("{:02X} ", block[r][c]);
        }
        println!();
    }
    println!();
}

fn combo_move_224_192(temp :&mut  [[u8;constants::KEY_COLUMNS_224_192];4], round_constant_index : usize){
    for r in 0..4{
        temp[r][0] ^= constants::SBOX_FORWARD[temp[(r+1)%4][constants::KEY_COLUMNS_224_192-1] as usize];
    }
    temp[0][0] ^= constants::ROUND_CONSTANTS[round_constant_index];
}
fn swoosh_move_224_192(temp  : &mut [[u8;constants::KEY_COLUMNS_224_192];4] ){
    /*
    if constants::KEY_COLUMNS_224_192 < 6{

        for c in 1..constants::KEY_COLUMNS_224_192{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }

    } else {
    */
        for c in 1..4{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
        for r in 0..4{
            temp[r][4] ^= constants::SBOX_FORWARD[(temp[r][3])as usize];
        }
        for c in 5..constants::KEY_COLUMNS_224_192{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    /*
    }
    */
}
fn load_move_224_192(temp : &[[u8;constants::KEY_COLUMNS_224_192];4],
expand_key : &mut [[[u8;constants::BLOCK_COLUMNS_224_192];4];constants::ROUNDS_224_192],
loads : usize,
expand_key_counter : &mut Counter){
    for c in 0..loads{
        for r in 0..4{
            expand_key[expand_key_counter.i][expand_key_counter.r][expand_key_counter.c]=temp[r][c];
            expand_key_counter.increment();
        }
    }
}

pub fn expand_key_224_192(key : &[u8;constants::KEY_BYTES_224_192],
expanded_key : &mut [[[u8;constants::BLOCK_COLUMNS_224_192];4];constants::ROUNDS_224_192]){
    //load into a local variable
    let mut round_constant_index : usize = 0;
    let mut temp : [[u8;constants::KEY_COLUMNS_224_192];4] =[[0;constants::KEY_COLUMNS_224_192];4];
    let mut expand_key_counter : Counter = Counter::new(constants::ROUNDS_224_192, constants::BLOCK_COLUMNS_224_192);
	let total_columns_needed : usize = constants::ROUNDS_224_192*constants::BLOCK_COLUMNS_224_192-constants::KEY_COLUMNS_224_192;
    let key_expansion_rounds_needed :usize = total_columns_needed/constants::KEY_COLUMNS_224_192;
    let key_expansion_remainder : usize = total_columns_needed%constants::KEY_COLUMNS_224_192;

    //load key into temporary matrix
    for c in 0..constants::KEY_COLUMNS_224_192{
        for r in 0..4{
            temp[r][c] = key[round_constant_index];
            round_constant_index+=1;
        }
    }
    //move temp into expanded key
    load_move_224_192(&temp, expanded_key, constants::KEY_COLUMNS_224_192, &mut expand_key_counter);
    //processing different for each type
    for round_constant_index in 1..key_expansion_rounds_needed+1{
        combo_move_224_192(&mut temp, round_constant_index);
        swoosh_move_224_192(&mut temp);
        load_move_224_192(&temp, expanded_key, constants::KEY_COLUMNS_224_192, &mut expand_key_counter);
    }
    if key_expansion_remainder > 0{
        combo_move_224_192(&mut temp, key_expansion_rounds_needed+1);
        swoosh_move_224_192(&mut temp);
        load_move_224_192(&temp, expanded_key, key_expansion_remainder, &mut expand_key_counter);
    }

}

pub fn encrypt_block_224_192(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_224_192];4];constants::ROUNDS_224_192],
input_block : & [u8;constants::BLOCK_BYTES_224_192],
destination_block : &mut [u8;constants::BLOCK_BYTES_224_192]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_224_192];4] = [[0;constants::BLOCK_COLUMNS_224_192];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_224_192];4];constants::ROUNDS_224_192] =
								[[[0;constants::BLOCK_COLUMNS_224_192];4];constants::ROUNDS_224_192];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_224_192{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_192{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_224_192{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }
    //add round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_192{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }
    //PROCESS ROUNDS
    for round in 1..(constants::ROUNDS_224_192-1){
        //substitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_192{
                local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
            }
        }

        //rotate rows
        for r in 1..4{
            let shift : usize = constants::SHIFTS_224_192[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_224_192-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_224_192-shift)..constants::BLOCK_COLUMNS_224_192{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_224_192];
            }
        }
        //mix_columns
        for c in 0..constants::BLOCK_COLUMNS_224_192{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_FORWARD[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_FORWARD[r][i]);
                }
            }
        }
        //add round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_192{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
    }
    //substitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_192{
            local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
        }
    }
    //rotate rows
    for r in 1..4{
            let shift : usize = constants::SHIFTS_224_192[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_224_192-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_224_192-shift)..constants::BLOCK_COLUMNS_224_192{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_224_192];
            }
    }
    //add final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_192{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_224_192-1][r][c];
        }
    }
    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_224_192{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


pub fn decrypt_block_224_192(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_224_192];4];constants::ROUNDS_224_192],
input_block : & [u8;constants::BLOCK_BYTES_224_192],
destination_block : &mut [u8;constants::BLOCK_BYTES_224_192]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_224_192];4] = [[0;constants::BLOCK_COLUMNS_224_192];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_224_192];4];constants::ROUNDS_224_192] =
								[[[0;constants::BLOCK_COLUMNS_224_192];4];constants::ROUNDS_224_192];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_224_192{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_192{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_224_192{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }

    //minus final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_192{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_224_192-1][r][c];
        }
    }

    //unrotate_rows
    for r in 1..4{
        let shift : usize = constants::SHIFTS_224_192[r];
        for i in (constants::BLOCK_COLUMNS_224_192-shift)..constants::BLOCK_COLUMNS_224_192{
            buffer[i+shift-constants::BLOCK_COLUMNS_224_192] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_224_192).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
    }

    //unsubstitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_192{
            local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
        }
    }

    for round in (1..(constants::ROUNDS_224_192-1)).rev(){
        //minus round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_192{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
        //unmix_columns
        for c in 0..constants::BLOCK_COLUMNS_224_192{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_REVERSE[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_REVERSE[r][i]);
                }
            }
        }

        //unrotate_rows
        for r in 1..4{
        let shift : usize = constants::SHIFTS_224_192[r];
        for i in (constants::BLOCK_COLUMNS_224_192-shift)..constants::BLOCK_COLUMNS_224_192{
            buffer[i+shift-constants::BLOCK_COLUMNS_224_192] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_224_192).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
        }

        //unsubstitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_192{
                local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
            }
        }


    }

    //minus round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_192{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }

    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_224_192{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


/***************************************************************************************************
 * function name:  expand_key_(KEY_SIZE)_(BLOCK_SIZE)
 *
 * function:       (self explanatory)
 *
 * arguments:      expanded_key = the expanded key to use
 *                 key = raw key bits
 *
 * return:         void
 *
 * notes:          (none)
 **************************************************************************************************/


pub fn print_key_expansion_224_224(expanded_key : & [[[u8;constants::BLOCK_COLUMNS_224_224];4];constants::ROUNDS_224_224]){
    for i in 0..constants::ROUNDS_224_224{
        for c in 0..constants::BLOCK_COLUMNS_224_224{
            for r in 0..4{
                print!("{:02X} ",expanded_key[i][r][c]);
            }
        }
        println!();
    }
    println!();
}


fn print_block_224_224(message : &str, block : &[[u8;constants::BLOCK_COLUMNS_224_224];4]){
    println!("{}", message);
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_224{
            print!("{:02X} ", block[r][c]);
        }
        println!();
    }
    println!();
}

fn combo_move_224_224(temp :&mut  [[u8;constants::KEY_COLUMNS_224_224];4], round_constant_index : usize){
    for r in 0..4{
        temp[r][0] ^= constants::SBOX_FORWARD[temp[(r+1)%4][constants::KEY_COLUMNS_224_224-1] as usize];
    }
    temp[0][0] ^= constants::ROUND_CONSTANTS[round_constant_index];
}
fn swoosh_move_224_224(temp  : &mut [[u8;constants::KEY_COLUMNS_224_224];4] ){
    /*
    if constants::KEY_COLUMNS_224_224 < 6{

        for c in 1..constants::KEY_COLUMNS_224_224{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }

    } else {
    */
        for c in 1..4{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
        for r in 0..4{
            temp[r][4] ^= constants::SBOX_FORWARD[(temp[r][3])as usize];
        }
        for c in 5..constants::KEY_COLUMNS_224_224{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    /*
    }
    */
}
fn load_move_224_224(temp : &[[u8;constants::KEY_COLUMNS_224_224];4],
expand_key : &mut [[[u8;constants::BLOCK_COLUMNS_224_224];4];constants::ROUNDS_224_224],
loads : usize,
expand_key_counter : &mut Counter){
    for c in 0..loads{
        for r in 0..4{
            expand_key[expand_key_counter.i][expand_key_counter.r][expand_key_counter.c]=temp[r][c];
            expand_key_counter.increment();
        }
    }
}

pub fn expand_key_224_224(key : &[u8;constants::KEY_BYTES_224_224],
expanded_key : &mut [[[u8;constants::BLOCK_COLUMNS_224_224];4];constants::ROUNDS_224_224]){
    //load into a local variable
    let mut round_constant_index : usize = 0;
    let mut temp : [[u8;constants::KEY_COLUMNS_224_224];4] =[[0;constants::KEY_COLUMNS_224_224];4];
    let mut expand_key_counter : Counter = Counter::new(constants::ROUNDS_224_224, constants::BLOCK_COLUMNS_224_224);
	let total_columns_needed : usize = constants::ROUNDS_224_224*constants::BLOCK_COLUMNS_224_224-constants::KEY_COLUMNS_224_224;
    let key_expansion_rounds_needed :usize = total_columns_needed/constants::KEY_COLUMNS_224_224;
    let key_expansion_remainder : usize = total_columns_needed%constants::KEY_COLUMNS_224_224;

    //load key into temporary matrix
    for c in 0..constants::KEY_COLUMNS_224_224{
        for r in 0..4{
            temp[r][c] = key[round_constant_index];
            round_constant_index+=1;
        }
    }
    //move temp into expanded key
    load_move_224_224(&temp, expanded_key, constants::KEY_COLUMNS_224_224, &mut expand_key_counter);
    //processing different for each type
    for round_constant_index in 1..key_expansion_rounds_needed+1{
        combo_move_224_224(&mut temp, round_constant_index);
        swoosh_move_224_224(&mut temp);
        load_move_224_224(&temp, expanded_key, constants::KEY_COLUMNS_224_224, &mut expand_key_counter);
    }
    if key_expansion_remainder > 0{
        combo_move_224_224(&mut temp, key_expansion_rounds_needed+1);
        swoosh_move_224_224(&mut temp);
        load_move_224_224(&temp, expanded_key, key_expansion_remainder, &mut expand_key_counter);
    }

}

pub fn encrypt_block_224_224(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_224_224];4];constants::ROUNDS_224_224],
input_block : & [u8;constants::BLOCK_BYTES_224_224],
destination_block : &mut [u8;constants::BLOCK_BYTES_224_224]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_224_224];4] = [[0;constants::BLOCK_COLUMNS_224_224];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_224_224];4];constants::ROUNDS_224_224] =
								[[[0;constants::BLOCK_COLUMNS_224_224];4];constants::ROUNDS_224_224];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_224_224{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_224{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_224_224{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }
    //add round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_224{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }
    //PROCESS ROUNDS
    for round in 1..(constants::ROUNDS_224_224-1){
        //substitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_224{
                local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
            }
        }

        //rotate rows
        for r in 1..4{
            let shift : usize = constants::SHIFTS_224_224[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_224_224-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_224_224-shift)..constants::BLOCK_COLUMNS_224_224{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_224_224];
            }
        }
        //mix_columns
        for c in 0..constants::BLOCK_COLUMNS_224_224{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_FORWARD[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_FORWARD[r][i]);
                }
            }
        }
        //add round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_224{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
    }
    //substitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_224{
            local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
        }
    }
    //rotate rows
    for r in 1..4{
            let shift : usize = constants::SHIFTS_224_224[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_224_224-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_224_224-shift)..constants::BLOCK_COLUMNS_224_224{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_224_224];
            }
    }
    //add final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_224{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_224_224-1][r][c];
        }
    }
    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_224_224{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


pub fn decrypt_block_224_224(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_224_224];4];constants::ROUNDS_224_224],
input_block : & [u8;constants::BLOCK_BYTES_224_224],
destination_block : &mut [u8;constants::BLOCK_BYTES_224_224]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_224_224];4] = [[0;constants::BLOCK_COLUMNS_224_224];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_224_224];4];constants::ROUNDS_224_224] =
								[[[0;constants::BLOCK_COLUMNS_224_224];4];constants::ROUNDS_224_224];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_224_224{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_224{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_224_224{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }

    //minus final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_224{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_224_224-1][r][c];
        }
    }

    //unrotate_rows
    for r in 1..4{
        let shift : usize = constants::SHIFTS_224_224[r];
        for i in (constants::BLOCK_COLUMNS_224_224-shift)..constants::BLOCK_COLUMNS_224_224{
            buffer[i+shift-constants::BLOCK_COLUMNS_224_224] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_224_224).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
    }

    //unsubstitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_224{
            local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
        }
    }

    for round in (1..(constants::ROUNDS_224_224-1)).rev(){
        //minus round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_224{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
        //unmix_columns
        for c in 0..constants::BLOCK_COLUMNS_224_224{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_REVERSE[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_REVERSE[r][i]);
                }
            }
        }

        //unrotate_rows
        for r in 1..4{
        let shift : usize = constants::SHIFTS_224_224[r];
        for i in (constants::BLOCK_COLUMNS_224_224-shift)..constants::BLOCK_COLUMNS_224_224{
            buffer[i+shift-constants::BLOCK_COLUMNS_224_224] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_224_224).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
        }

        //unsubstitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_224{
                local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
            }
        }


    }

    //minus round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_224{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }

    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_224_224{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


/***************************************************************************************************
 * function name:  expand_key_(KEY_SIZE)_(BLOCK_SIZE)
 *
 * function:       (self explanatory)
 *
 * arguments:      expanded_key = the expanded key to use
 *                 key = raw key bits
 *
 * return:         void
 *
 * notes:          (none)
 **************************************************************************************************/


pub fn print_key_expansion_224_256(expanded_key : & [[[u8;constants::BLOCK_COLUMNS_224_256];4];constants::ROUNDS_224_256]){
    for i in 0..constants::ROUNDS_224_256{
        for c in 0..constants::BLOCK_COLUMNS_224_256{
            for r in 0..4{
                print!("{:02X} ",expanded_key[i][r][c]);
            }
        }
        println!();
    }
    println!();
}


fn print_block_224_256(message : &str, block : &[[u8;constants::BLOCK_COLUMNS_224_256];4]){
    println!("{}", message);
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_256{
            print!("{:02X} ", block[r][c]);
        }
        println!();
    }
    println!();
}

fn combo_move_224_256(temp :&mut  [[u8;constants::KEY_COLUMNS_224_256];4], round_constant_index : usize){
    for r in 0..4{
        temp[r][0] ^= constants::SBOX_FORWARD[temp[(r+1)%4][constants::KEY_COLUMNS_224_256-1] as usize];
    }
    temp[0][0] ^= constants::ROUND_CONSTANTS[round_constant_index];
}
fn swoosh_move_224_256(temp  : &mut [[u8;constants::KEY_COLUMNS_224_256];4] ){
    /*
    if constants::KEY_COLUMNS_224_256 < 6{

        for c in 1..constants::KEY_COLUMNS_224_256{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }

    } else {
    */
        for c in 1..4{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
        for r in 0..4{
            temp[r][4] ^= constants::SBOX_FORWARD[(temp[r][3])as usize];
        }
        for c in 5..constants::KEY_COLUMNS_224_256{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    /*
    }
    */
}
fn load_move_224_256(temp : &[[u8;constants::KEY_COLUMNS_224_256];4],
expand_key : &mut [[[u8;constants::BLOCK_COLUMNS_224_256];4];constants::ROUNDS_224_256],
loads : usize,
expand_key_counter : &mut Counter){
    for c in 0..loads{
        for r in 0..4{
            expand_key[expand_key_counter.i][expand_key_counter.r][expand_key_counter.c]=temp[r][c];
            expand_key_counter.increment();
        }
    }
}

pub fn expand_key_224_256(key : &[u8;constants::KEY_BYTES_224_256],
expanded_key : &mut [[[u8;constants::BLOCK_COLUMNS_224_256];4];constants::ROUNDS_224_256]){
    //load into a local variable
    let mut round_constant_index : usize = 0;
    let mut temp : [[u8;constants::KEY_COLUMNS_224_256];4] =[[0;constants::KEY_COLUMNS_224_256];4];
    let mut expand_key_counter : Counter = Counter::new(constants::ROUNDS_224_256, constants::BLOCK_COLUMNS_224_256);
	let total_columns_needed : usize = constants::ROUNDS_224_256*constants::BLOCK_COLUMNS_224_256-constants::KEY_COLUMNS_224_256;
    let key_expansion_rounds_needed :usize = total_columns_needed/constants::KEY_COLUMNS_224_256;
    let key_expansion_remainder : usize = total_columns_needed%constants::KEY_COLUMNS_224_256;

    //load key into temporary matrix
    for c in 0..constants::KEY_COLUMNS_224_256{
        for r in 0..4{
            temp[r][c] = key[round_constant_index];
            round_constant_index+=1;
        }
    }
    //move temp into expanded key
    load_move_224_256(&temp, expanded_key, constants::KEY_COLUMNS_224_256, &mut expand_key_counter);
    //processing different for each type
    for round_constant_index in 1..key_expansion_rounds_needed+1{
        combo_move_224_256(&mut temp, round_constant_index);
        swoosh_move_224_256(&mut temp);
        load_move_224_256(&temp, expanded_key, constants::KEY_COLUMNS_224_256, &mut expand_key_counter);
    }
    if key_expansion_remainder > 0{
        combo_move_224_256(&mut temp, key_expansion_rounds_needed+1);
        swoosh_move_224_256(&mut temp);
        load_move_224_256(&temp, expanded_key, key_expansion_remainder, &mut expand_key_counter);
    }

}

pub fn encrypt_block_224_256(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_224_256];4];constants::ROUNDS_224_256],
input_block : & [u8;constants::BLOCK_BYTES_224_256],
destination_block : &mut [u8;constants::BLOCK_BYTES_224_256]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_224_256];4] = [[0;constants::BLOCK_COLUMNS_224_256];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_224_256];4];constants::ROUNDS_224_256] =
								[[[0;constants::BLOCK_COLUMNS_224_256];4];constants::ROUNDS_224_256];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_224_256{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_256{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_224_256{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }
    //add round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_256{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }
    //PROCESS ROUNDS
    for round in 1..(constants::ROUNDS_224_256-1){
        //substitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_256{
                local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
            }
        }

        //rotate rows
        for r in 1..4{
            let shift : usize = constants::SHIFTS_224_256[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_224_256-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_224_256-shift)..constants::BLOCK_COLUMNS_224_256{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_224_256];
            }
        }
        //mix_columns
        for c in 0..constants::BLOCK_COLUMNS_224_256{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_FORWARD[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_FORWARD[r][i]);
                }
            }
        }
        //add round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_256{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
    }
    //substitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_256{
            local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
        }
    }
    //rotate rows
    for r in 1..4{
            let shift : usize = constants::SHIFTS_224_256[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_224_256-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_224_256-shift)..constants::BLOCK_COLUMNS_224_256{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_224_256];
            }
    }
    //add final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_256{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_224_256-1][r][c];
        }
    }
    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_224_256{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


pub fn decrypt_block_224_256(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_224_256];4];constants::ROUNDS_224_256],
input_block : & [u8;constants::BLOCK_BYTES_224_256],
destination_block : &mut [u8;constants::BLOCK_BYTES_224_256]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_224_256];4] = [[0;constants::BLOCK_COLUMNS_224_256];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_224_256];4];constants::ROUNDS_224_256] =
								[[[0;constants::BLOCK_COLUMNS_224_256];4];constants::ROUNDS_224_256];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_224_256{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_256{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_224_256{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }

    //minus final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_256{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_224_256-1][r][c];
        }
    }

    //unrotate_rows
    for r in 1..4{
        let shift : usize = constants::SHIFTS_224_256[r];
        for i in (constants::BLOCK_COLUMNS_224_256-shift)..constants::BLOCK_COLUMNS_224_256{
            buffer[i+shift-constants::BLOCK_COLUMNS_224_256] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_224_256).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
    }

    //unsubstitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_256{
            local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
        }
    }

    for round in (1..(constants::ROUNDS_224_256-1)).rev(){
        //minus round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_256{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
        //unmix_columns
        for c in 0..constants::BLOCK_COLUMNS_224_256{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_REVERSE[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_REVERSE[r][i]);
                }
            }
        }

        //unrotate_rows
        for r in 1..4{
        let shift : usize = constants::SHIFTS_224_256[r];
        for i in (constants::BLOCK_COLUMNS_224_256-shift)..constants::BLOCK_COLUMNS_224_256{
            buffer[i+shift-constants::BLOCK_COLUMNS_224_256] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_224_256).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
        }

        //unsubstitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_224_256{
                local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
            }
        }


    }

    //minus round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_224_256{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }

    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_224_256{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}

/***************************************************************************************************
 * function name:  expand_key_(KEY_SIZE)_(BLOCK_SIZE)
 *
 * function:       (self explanatory)
 *
 * arguments:      expanded_key = the expanded key to use
 *                 key = raw key bits
 *
 * return:         void
 *
 * notes:          (none)
 **************************************************************************************************/


pub fn print_key_expansion_256_128(expanded_key : & [[[u8;constants::BLOCK_COLUMNS_256_128];4];constants::ROUNDS_256_128]){
    for i in 0..constants::ROUNDS_256_128{
        for c in 0..constants::BLOCK_COLUMNS_256_128{
            for r in 0..4{
                print!("{:02X} ",expanded_key[i][r][c]);
            }
        }
        println!();
    }
    println!();
}


fn print_block_256_128(message : &str, block : &[[u8;constants::BLOCK_COLUMNS_256_128];4]){
    println!("{}", message);
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_128{
            print!("{:02X} ", block[r][c]);
        }
        println!();
    }
    println!();
}

fn combo_move_256_128(temp :&mut  [[u8;constants::KEY_COLUMNS_256_128];4], round_constant_index : usize){
    for r in 0..4{
        temp[r][0] ^= constants::SBOX_FORWARD[temp[(r+1)%4][constants::KEY_COLUMNS_256_128-1] as usize];
    }
    temp[0][0] ^= constants::ROUND_CONSTANTS[round_constant_index];
}
fn swoosh_move_256_128(temp  : &mut [[u8;constants::KEY_COLUMNS_256_128];4] ){
    /*
    if constants::KEY_COLUMNS_256_128 < 6{

        for c in 1..constants::KEY_COLUMNS_256_128{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }

    } else {
    */
        for c in 1..4{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
        for r in 0..4{
            temp[r][4] ^= constants::SBOX_FORWARD[(temp[r][3])as usize];
        }
        for c in 5..constants::KEY_COLUMNS_256_128{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    /*
    }
    */
}
fn load_move_256_128(temp : &[[u8;constants::KEY_COLUMNS_256_128];4],
expand_key : &mut [[[u8;constants::BLOCK_COLUMNS_256_128];4];constants::ROUNDS_256_128],
loads : usize,
expand_key_counter : &mut Counter){
    for c in 0..loads{
        for r in 0..4{
            expand_key[expand_key_counter.i][expand_key_counter.r][expand_key_counter.c]=temp[r][c];
            expand_key_counter.increment();
        }
    }
}

pub fn expand_key_256_128(key : &[u8;constants::KEY_BYTES_256_128],
expanded_key : &mut [[[u8;constants::BLOCK_COLUMNS_256_128];4];constants::ROUNDS_256_128]){
    //load into a local variable
    let mut round_constant_index : usize = 0;
    let mut temp : [[u8;constants::KEY_COLUMNS_256_128];4] =[[0;constants::KEY_COLUMNS_256_128];4];
    let mut expand_key_counter : Counter = Counter::new(constants::ROUNDS_256_128, constants::BLOCK_COLUMNS_256_128);
	let total_columns_needed : usize = constants::ROUNDS_256_128*constants::BLOCK_COLUMNS_256_128-constants::KEY_COLUMNS_256_128;
    let key_expansion_rounds_needed :usize = total_columns_needed/constants::KEY_COLUMNS_256_128;
    let key_expansion_remainder : usize = total_columns_needed%constants::KEY_COLUMNS_256_128;

    //load key into temporary matrix
    for c in 0..constants::KEY_COLUMNS_256_128{
        for r in 0..4{
            temp[r][c] = key[round_constant_index];
            round_constant_index+=1;
        }
    }
    //move temp into expanded key
    load_move_256_128(&temp, expanded_key, constants::KEY_COLUMNS_256_128, &mut expand_key_counter);
    //processing different for each type
    for round_constant_index in 1..key_expansion_rounds_needed+1{
        combo_move_256_128(&mut temp, round_constant_index);
        swoosh_move_256_128(&mut temp);
        load_move_256_128(&temp, expanded_key, constants::KEY_COLUMNS_256_128, &mut expand_key_counter);
    }
    if key_expansion_remainder > 0{
        combo_move_256_128(&mut temp, key_expansion_rounds_needed+1);
        swoosh_move_256_128(&mut temp);
        load_move_256_128(&temp, expanded_key, key_expansion_remainder, &mut expand_key_counter);
    }

}

pub fn encrypt_block_256_128(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_256_128];4];constants::ROUNDS_256_128],
input_block : & [u8;constants::BLOCK_BYTES_256_128],
destination_block : &mut [u8;constants::BLOCK_BYTES_256_128]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_256_128];4] = [[0;constants::BLOCK_COLUMNS_256_128];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_256_128];4];constants::ROUNDS_256_128] =
								[[[0;constants::BLOCK_COLUMNS_256_128];4];constants::ROUNDS_256_128];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_256_128{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_128{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_256_128{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }
    //add round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_128{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }
    //PROCESS ROUNDS
    for round in 1..(constants::ROUNDS_256_128-1){
        //substitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_128{
                local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
            }
        }

        //rotate rows
        for r in 1..4{
            let shift : usize = constants::SHIFTS_256_128[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_256_128-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_256_128-shift)..constants::BLOCK_COLUMNS_256_128{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_256_128];
            }
        }
        //mix_columns
        for c in 0..constants::BLOCK_COLUMNS_256_128{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_FORWARD[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_FORWARD[r][i]);
                }
            }
        }
        //add round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_128{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
    }
    //substitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_128{
            local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
        }
    }
    //rotate rows
    for r in 1..4{
            let shift : usize = constants::SHIFTS_256_128[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_256_128-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_256_128-shift)..constants::BLOCK_COLUMNS_256_128{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_256_128];
            }
    }
    //add final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_128{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_256_128-1][r][c];
        }
    }
    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_256_128{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


pub fn decrypt_block_256_128(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_256_128];4];constants::ROUNDS_256_128],
input_block : & [u8;constants::BLOCK_BYTES_256_128],
destination_block : &mut [u8;constants::BLOCK_BYTES_256_128]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_256_128];4] = [[0;constants::BLOCK_COLUMNS_256_128];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_256_128];4];constants::ROUNDS_256_128] =
								[[[0;constants::BLOCK_COLUMNS_256_128];4];constants::ROUNDS_256_128];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_256_128{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_128{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_256_128{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }

    //minus final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_128{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_256_128-1][r][c];
        }
    }

    //unrotate_rows
    for r in 1..4{
        let shift : usize = constants::SHIFTS_256_128[r];
        for i in (constants::BLOCK_COLUMNS_256_128-shift)..constants::BLOCK_COLUMNS_256_128{
            buffer[i+shift-constants::BLOCK_COLUMNS_256_128] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_256_128).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
    }

    //unsubstitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_128{
            local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
        }
    }

    for round in (1..(constants::ROUNDS_256_128-1)).rev(){
        //minus round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_128{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
        //unmix_columns
        for c in 0..constants::BLOCK_COLUMNS_256_128{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_REVERSE[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_REVERSE[r][i]);
                }
            }
        }

        //unrotate_rows
        for r in 1..4{
        let shift : usize = constants::SHIFTS_256_128[r];
        for i in (constants::BLOCK_COLUMNS_256_128-shift)..constants::BLOCK_COLUMNS_256_128{
            buffer[i+shift-constants::BLOCK_COLUMNS_256_128] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_256_128).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
        }

        //unsubstitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_128{
                local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
            }
        }


    }

    //minus round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_128{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }

    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_256_128{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}

/***************************************************************************************************
 * function name:  expand_key_(KEY_SIZE)_(BLOCK_SIZE)
 *
 * function:       (self explanatory)
 *
 * arguments:      expanded_key = the expanded key to use
 *                 key = raw key bits
 *
 * return:         void
 *
 * notes:          (none)
 **************************************************************************************************/


pub fn print_key_expansion_256_160(expanded_key : & [[[u8;constants::BLOCK_COLUMNS_256_160];4];constants::ROUNDS_256_160]){
    for i in 0..constants::ROUNDS_256_160{
        for c in 0..constants::BLOCK_COLUMNS_256_160{
            for r in 0..4{
                print!("{:02X} ",expanded_key[i][r][c]);
            }
        }
        println!();
    }
    println!();
}


fn print_block_256_160(message : &str, block : &[[u8;constants::BLOCK_COLUMNS_256_160];4]){
    println!("{}", message);
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_160{
            print!("{:02X} ", block[r][c]);
        }
        println!();
    }
    println!();
}

fn combo_move_256_160(temp :&mut  [[u8;constants::KEY_COLUMNS_256_160];4], round_constant_index : usize){
    for r in 0..4{
        temp[r][0] ^= constants::SBOX_FORWARD[temp[(r+1)%4][constants::KEY_COLUMNS_256_160-1] as usize];
    }
    temp[0][0] ^= constants::ROUND_CONSTANTS[round_constant_index];
}
fn swoosh_move_256_160(temp  : &mut [[u8;constants::KEY_COLUMNS_256_160];4] ){
    /*
    if constants::KEY_COLUMNS_256_160 < 6{

        for c in 1..constants::KEY_COLUMNS_256_160{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }

    } else {
    */
        for c in 1..4{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
        for r in 0..4{
            temp[r][4] ^= constants::SBOX_FORWARD[(temp[r][3])as usize];
        }
        for c in 5..constants::KEY_COLUMNS_256_160{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    /*
    }
    */
}
fn load_move_256_160(temp : &[[u8;constants::KEY_COLUMNS_256_160];4],
expand_key : &mut [[[u8;constants::BLOCK_COLUMNS_256_160];4];constants::ROUNDS_256_160],
loads : usize,
expand_key_counter : &mut Counter){
    for c in 0..loads{
        for r in 0..4{
            expand_key[expand_key_counter.i][expand_key_counter.r][expand_key_counter.c]=temp[r][c];
            expand_key_counter.increment();
        }
    }
}

pub fn expand_key_256_160(key : &[u8;constants::KEY_BYTES_256_160],
expanded_key : &mut [[[u8;constants::BLOCK_COLUMNS_256_160];4];constants::ROUNDS_256_160]){
    //load into a local variable
    let mut round_constant_index : usize = 0;
    let mut temp : [[u8;constants::KEY_COLUMNS_256_160];4] =[[0;constants::KEY_COLUMNS_256_160];4];
    let mut expand_key_counter : Counter = Counter::new(constants::ROUNDS_256_160, constants::BLOCK_COLUMNS_256_160);
	let total_columns_needed : usize = constants::ROUNDS_256_160*constants::BLOCK_COLUMNS_256_160-constants::KEY_COLUMNS_256_160;
    let key_expansion_rounds_needed :usize = total_columns_needed/constants::KEY_COLUMNS_256_160;
    let key_expansion_remainder : usize = total_columns_needed%constants::KEY_COLUMNS_256_160;

    //load key into temporary matrix
    for c in 0..constants::KEY_COLUMNS_256_160{
        for r in 0..4{
            temp[r][c] = key[round_constant_index];
            round_constant_index+=1;
        }
    }
    //move temp into expanded key
    load_move_256_160(&temp, expanded_key, constants::KEY_COLUMNS_256_160, &mut expand_key_counter);
    //processing different for each type
    for round_constant_index in 1..key_expansion_rounds_needed+1{
        combo_move_256_160(&mut temp, round_constant_index);
        swoosh_move_256_160(&mut temp);
        load_move_256_160(&temp, expanded_key, constants::KEY_COLUMNS_256_160, &mut expand_key_counter);
    }
    if key_expansion_remainder > 0{
        combo_move_256_160(&mut temp, key_expansion_rounds_needed+1);
        swoosh_move_256_160(&mut temp);
        load_move_256_160(&temp, expanded_key, key_expansion_remainder, &mut expand_key_counter);
    }

}

pub fn encrypt_block_256_160(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_256_160];4];constants::ROUNDS_256_160],
input_block : & [u8;constants::BLOCK_BYTES_256_160],
destination_block : &mut [u8;constants::BLOCK_BYTES_256_160]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_256_160];4] = [[0;constants::BLOCK_COLUMNS_256_160];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_256_160];4];constants::ROUNDS_256_160] =
								[[[0;constants::BLOCK_COLUMNS_256_160];4];constants::ROUNDS_256_160];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_256_160{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_160{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_256_160{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }
    //add round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_160{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }
    //PROCESS ROUNDS
    for round in 1..(constants::ROUNDS_256_160-1){
        //substitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_160{
                local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
            }
        }

        //rotate rows
        for r in 1..4{
            let shift : usize = constants::SHIFTS_256_160[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_256_160-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_256_160-shift)..constants::BLOCK_COLUMNS_256_160{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_256_160];
            }
        }
        //mix_columns
        for c in 0..constants::BLOCK_COLUMNS_256_160{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_FORWARD[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_FORWARD[r][i]);
                }
            }
        }
        //add round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_160{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
    }
    //substitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_160{
            local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
        }
    }
    //rotate rows
    for r in 1..4{
            let shift : usize = constants::SHIFTS_256_160[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_256_160-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_256_160-shift)..constants::BLOCK_COLUMNS_256_160{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_256_160];
            }
    }
    //add final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_160{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_256_160-1][r][c];
        }
    }
    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_256_160{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


pub fn decrypt_block_256_160(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_256_160];4];constants::ROUNDS_256_160],
input_block : & [u8;constants::BLOCK_BYTES_256_160],
destination_block : &mut [u8;constants::BLOCK_BYTES_256_160]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_256_160];4] = [[0;constants::BLOCK_COLUMNS_256_160];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_256_160];4];constants::ROUNDS_256_160] =
								[[[0;constants::BLOCK_COLUMNS_256_160];4];constants::ROUNDS_256_160];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_256_160{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_160{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_256_160{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }

    //minus final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_160{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_256_160-1][r][c];
        }
    }

    //unrotate_rows
    for r in 1..4{
        let shift : usize = constants::SHIFTS_256_160[r];
        for i in (constants::BLOCK_COLUMNS_256_160-shift)..constants::BLOCK_COLUMNS_256_160{
            buffer[i+shift-constants::BLOCK_COLUMNS_256_160] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_256_160).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
    }

    //unsubstitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_160{
            local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
        }
    }

    for round in (1..(constants::ROUNDS_256_160-1)).rev(){
        //minus round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_160{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
        //unmix_columns
        for c in 0..constants::BLOCK_COLUMNS_256_160{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_REVERSE[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_REVERSE[r][i]);
                }
            }
        }

        //unrotate_rows
        for r in 1..4{
        let shift : usize = constants::SHIFTS_256_160[r];
        for i in (constants::BLOCK_COLUMNS_256_160-shift)..constants::BLOCK_COLUMNS_256_160{
            buffer[i+shift-constants::BLOCK_COLUMNS_256_160] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_256_160).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
        }

        //unsubstitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_160{
                local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
            }
        }


    }

    //minus round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_160{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }

    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_256_160{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}

/***************************************************************************************************
 * function name:  expand_key_(KEY_SIZE)_(BLOCK_SIZE)
 *
 * function:       (self explanatory)
 *
 * arguments:      expanded_key = the expanded key to use
 *                 key = raw key bits
 *
 * return:         void
 *
 * notes:          (none)
 **************************************************************************************************/


pub fn print_key_expansion_256_192(expanded_key : & [[[u8;constants::BLOCK_COLUMNS_256_192];4];constants::ROUNDS_256_192]){
    for i in 0..constants::ROUNDS_256_192{
        for c in 0..constants::BLOCK_COLUMNS_256_192{
            for r in 0..4{
                print!("{:02X} ",expanded_key[i][r][c]);
            }
        }
        println!();
    }
    println!();
}


fn print_block_256_192(message : &str, block : &[[u8;constants::BLOCK_COLUMNS_256_192];4]){
    println!("{}", message);
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_192{
            print!("{:02X} ", block[r][c]);
        }
        println!();
    }
    println!();
}

fn combo_move_256_192(temp :&mut  [[u8;constants::KEY_COLUMNS_256_192];4], round_constant_index : usize){
    for r in 0..4{
        temp[r][0] ^= constants::SBOX_FORWARD[temp[(r+1)%4][constants::KEY_COLUMNS_256_192-1] as usize];
    }
    temp[0][0] ^= constants::ROUND_CONSTANTS[round_constant_index];
}
fn swoosh_move_256_192(temp  : &mut [[u8;constants::KEY_COLUMNS_256_192];4] ){
    /*
    if constants::KEY_COLUMNS_256_192 < 6{

        for c in 1..constants::KEY_COLUMNS_256_192{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }

    } else {
    */
        for c in 1..4{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
        for r in 0..4{
            temp[r][4] ^= constants::SBOX_FORWARD[(temp[r][3])as usize];
        }
        for c in 5..constants::KEY_COLUMNS_256_192{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    /*
    }
    */
}
fn load_move_256_192(temp : &[[u8;constants::KEY_COLUMNS_256_192];4],
expand_key : &mut [[[u8;constants::BLOCK_COLUMNS_256_192];4];constants::ROUNDS_256_192],
loads : usize,
expand_key_counter : &mut Counter){
    for c in 0..loads{
        for r in 0..4{
            expand_key[expand_key_counter.i][expand_key_counter.r][expand_key_counter.c]=temp[r][c];
            expand_key_counter.increment();
        }
    }
}

pub fn expand_key_256_192(key : &[u8;constants::KEY_BYTES_256_192],
expanded_key : &mut [[[u8;constants::BLOCK_COLUMNS_256_192];4];constants::ROUNDS_256_192]){
    //load into a local variable
    let mut round_constant_index : usize = 0;
    let mut temp : [[u8;constants::KEY_COLUMNS_256_192];4] =[[0;constants::KEY_COLUMNS_256_192];4];
    let mut expand_key_counter : Counter = Counter::new(constants::ROUNDS_256_192, constants::BLOCK_COLUMNS_256_192);
	let total_columns_needed : usize = constants::ROUNDS_256_192*constants::BLOCK_COLUMNS_256_192-constants::KEY_COLUMNS_256_192;
    let key_expansion_rounds_needed :usize = total_columns_needed/constants::KEY_COLUMNS_256_192;
    let key_expansion_remainder : usize = total_columns_needed%constants::KEY_COLUMNS_256_192;

    //load key into temporary matrix
    for c in 0..constants::KEY_COLUMNS_256_192{
        for r in 0..4{
            temp[r][c] = key[round_constant_index];
            round_constant_index+=1;
        }
    }
    //move temp into expanded key
    load_move_256_192(&temp, expanded_key, constants::KEY_COLUMNS_256_192, &mut expand_key_counter);
    //processing different for each type
    for round_constant_index in 1..key_expansion_rounds_needed+1{
        combo_move_256_192(&mut temp, round_constant_index);
        swoosh_move_256_192(&mut temp);
        load_move_256_192(&temp, expanded_key, constants::KEY_COLUMNS_256_192, &mut expand_key_counter);
    }
    if key_expansion_remainder > 0{
        combo_move_256_192(&mut temp, key_expansion_rounds_needed+1);
        swoosh_move_256_192(&mut temp);
        load_move_256_192(&temp, expanded_key, key_expansion_remainder, &mut expand_key_counter);
    }

}

pub fn encrypt_block_256_192(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_256_192];4];constants::ROUNDS_256_192],
input_block : & [u8;constants::BLOCK_BYTES_256_192],
destination_block : &mut [u8;constants::BLOCK_BYTES_256_192]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_256_192];4] = [[0;constants::BLOCK_COLUMNS_256_192];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_256_192];4];constants::ROUNDS_256_192] =
								[[[0;constants::BLOCK_COLUMNS_256_192];4];constants::ROUNDS_256_192];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_256_192{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_192{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_256_192{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }
    //add round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_192{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }
    //PROCESS ROUNDS
    for round in 1..(constants::ROUNDS_256_192-1){
        //substitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_192{
                local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
            }
        }

        //rotate rows
        for r in 1..4{
            let shift : usize = constants::SHIFTS_256_192[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_256_192-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_256_192-shift)..constants::BLOCK_COLUMNS_256_192{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_256_192];
            }
        }
        //mix_columns
        for c in 0..constants::BLOCK_COLUMNS_256_192{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_FORWARD[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_FORWARD[r][i]);
                }
            }
        }
        //add round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_192{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
    }
    //substitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_192{
            local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
        }
    }
    //rotate rows
    for r in 1..4{
            let shift : usize = constants::SHIFTS_256_192[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_256_192-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_256_192-shift)..constants::BLOCK_COLUMNS_256_192{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_256_192];
            }
    }
    //add final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_192{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_256_192-1][r][c];
        }
    }
    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_256_192{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


pub fn decrypt_block_256_192(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_256_192];4];constants::ROUNDS_256_192],
input_block : & [u8;constants::BLOCK_BYTES_256_192],
destination_block : &mut [u8;constants::BLOCK_BYTES_256_192]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_256_192];4] = [[0;constants::BLOCK_COLUMNS_256_192];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_256_192];4];constants::ROUNDS_256_192] =
								[[[0;constants::BLOCK_COLUMNS_256_192];4];constants::ROUNDS_256_192];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_256_192{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_192{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_256_192{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }

    //minus final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_192{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_256_192-1][r][c];
        }
    }

    //unrotate_rows
    for r in 1..4{
        let shift : usize = constants::SHIFTS_256_192[r];
        for i in (constants::BLOCK_COLUMNS_256_192-shift)..constants::BLOCK_COLUMNS_256_192{
            buffer[i+shift-constants::BLOCK_COLUMNS_256_192] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_256_192).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
    }

    //unsubstitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_192{
            local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
        }
    }

    for round in (1..(constants::ROUNDS_256_192-1)).rev(){
        //minus round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_192{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
        //unmix_columns
        for c in 0..constants::BLOCK_COLUMNS_256_192{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_REVERSE[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_REVERSE[r][i]);
                }
            }
        }

        //unrotate_rows
        for r in 1..4{
        let shift : usize = constants::SHIFTS_256_192[r];
        for i in (constants::BLOCK_COLUMNS_256_192-shift)..constants::BLOCK_COLUMNS_256_192{
            buffer[i+shift-constants::BLOCK_COLUMNS_256_192] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_256_192).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
        }

        //unsubstitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_192{
                local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
            }
        }


    }

    //minus round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_192{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }

    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_256_192{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}

/***************************************************************************************************
 * function name:  expand_key_(KEY_SIZE)_(BLOCK_SIZE)
 *
 * function:       (self explanatory)
 *
 * arguments:      expanded_key = the expanded key to use
 *                 key = raw key bits
 *
 * return:         void
 *
 * notes:          (none)
 **************************************************************************************************/


pub fn print_key_expansion_256_224(expanded_key : & [[[u8;constants::BLOCK_COLUMNS_256_224];4];constants::ROUNDS_256_224]){
    for i in 0..constants::ROUNDS_256_224{
        for c in 0..constants::BLOCK_COLUMNS_256_224{
            for r in 0..4{
                print!("{:02X} ",expanded_key[i][r][c]);
            }
        }
        println!();
    }
    println!();
}


fn print_block_256_224(message : &str, block : &[[u8;constants::BLOCK_COLUMNS_256_224];4]){
    println!("{}", message);
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_224{
            print!("{:02X} ", block[r][c]);
        }
        println!();
    }
    println!();
}

fn combo_move_256_224(temp :&mut  [[u8;constants::KEY_COLUMNS_256_224];4], round_constant_index : usize){
    for r in 0..4{
        temp[r][0] ^= constants::SBOX_FORWARD[temp[(r+1)%4][constants::KEY_COLUMNS_256_224-1] as usize];
    }
    temp[0][0] ^= constants::ROUND_CONSTANTS[round_constant_index];
}
fn swoosh_move_256_224(temp  : &mut [[u8;constants::KEY_COLUMNS_256_224];4] ){
    /*
    if constants::KEY_COLUMNS_256_224 < 6{

        for c in 1..constants::KEY_COLUMNS_256_224{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }

    } else {
    */
        for c in 1..4{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
        for r in 0..4{
            temp[r][4] ^= constants::SBOX_FORWARD[(temp[r][3])as usize];
        }
        for c in 5..constants::KEY_COLUMNS_256_224{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    /*
    }
    */
}
fn load_move_256_224(temp : &[[u8;constants::KEY_COLUMNS_256_224];4],
expand_key : &mut [[[u8;constants::BLOCK_COLUMNS_256_224];4];constants::ROUNDS_256_224],
loads : usize,
expand_key_counter : &mut Counter){
    for c in 0..loads{
        for r in 0..4{
            expand_key[expand_key_counter.i][expand_key_counter.r][expand_key_counter.c]=temp[r][c];
            expand_key_counter.increment();
        }
    }
}

pub fn expand_key_256_224(key : &[u8;constants::KEY_BYTES_256_224],
expanded_key : &mut [[[u8;constants::BLOCK_COLUMNS_256_224];4];constants::ROUNDS_256_224]){
    //load into a local variable
    let mut round_constant_index : usize = 0;
    let mut temp : [[u8;constants::KEY_COLUMNS_256_224];4] =[[0;constants::KEY_COLUMNS_256_224];4];
    let mut expand_key_counter : Counter = Counter::new(constants::ROUNDS_256_224, constants::BLOCK_COLUMNS_256_224);
	let total_columns_needed : usize = constants::ROUNDS_256_224*constants::BLOCK_COLUMNS_256_224-constants::KEY_COLUMNS_256_224;
    let key_expansion_rounds_needed :usize = total_columns_needed/constants::KEY_COLUMNS_256_224;
    let key_expansion_remainder : usize = total_columns_needed%constants::KEY_COLUMNS_256_224;

    //load key into temporary matrix
    for c in 0..constants::KEY_COLUMNS_256_224{
        for r in 0..4{
            temp[r][c] = key[round_constant_index];
            round_constant_index+=1;
        }
    }
    //move temp into expanded key
    load_move_256_224(&temp, expanded_key, constants::KEY_COLUMNS_256_224, &mut expand_key_counter);
    //processing different for each type
    for round_constant_index in 1..key_expansion_rounds_needed+1{
        combo_move_256_224(&mut temp, round_constant_index);
        swoosh_move_256_224(&mut temp);
        load_move_256_224(&temp, expanded_key, constants::KEY_COLUMNS_256_224, &mut expand_key_counter);
    }
    if key_expansion_remainder > 0{
        combo_move_256_224(&mut temp, key_expansion_rounds_needed+1);
        swoosh_move_256_224(&mut temp);
        load_move_256_224(&temp, expanded_key, key_expansion_remainder, &mut expand_key_counter);
    }

}

pub fn encrypt_block_256_224(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_256_224];4];constants::ROUNDS_256_224],
input_block : & [u8;constants::BLOCK_BYTES_256_224],
destination_block : &mut [u8;constants::BLOCK_BYTES_256_224]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_256_224];4] = [[0;constants::BLOCK_COLUMNS_256_224];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_256_224];4];constants::ROUNDS_256_224] =
								[[[0;constants::BLOCK_COLUMNS_256_224];4];constants::ROUNDS_256_224];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_256_224{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_224{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_256_224{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }
    //add round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_224{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }
    //PROCESS ROUNDS
    for round in 1..(constants::ROUNDS_256_224-1){
        //substitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_224{
                local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
            }
        }

        //rotate rows
        for r in 1..4{
            let shift : usize = constants::SHIFTS_256_224[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_256_224-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_256_224-shift)..constants::BLOCK_COLUMNS_256_224{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_256_224];
            }
        }
        //mix_columns
        for c in 0..constants::BLOCK_COLUMNS_256_224{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_FORWARD[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_FORWARD[r][i]);
                }
            }
        }
        //add round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_224{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
    }
    //substitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_224{
            local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
        }
    }
    //rotate rows
    for r in 1..4{
            let shift : usize = constants::SHIFTS_256_224[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_256_224-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_256_224-shift)..constants::BLOCK_COLUMNS_256_224{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_256_224];
            }
    }
    //add final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_224{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_256_224-1][r][c];
        }
    }
    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_256_224{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


pub fn decrypt_block_256_224(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_256_224];4];constants::ROUNDS_256_224],
input_block : & [u8;constants::BLOCK_BYTES_256_224],
destination_block : &mut [u8;constants::BLOCK_BYTES_256_224]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_256_224];4] = [[0;constants::BLOCK_COLUMNS_256_224];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_256_224];4];constants::ROUNDS_256_224] =
								[[[0;constants::BLOCK_COLUMNS_256_224];4];constants::ROUNDS_256_224];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_256_224{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_224{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_256_224{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }

    //minus final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_224{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_256_224-1][r][c];
        }
    }

    //unrotate_rows
    for r in 1..4{
        let shift : usize = constants::SHIFTS_256_224[r];
        for i in (constants::BLOCK_COLUMNS_256_224-shift)..constants::BLOCK_COLUMNS_256_224{
            buffer[i+shift-constants::BLOCK_COLUMNS_256_224] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_256_224).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
    }

    //unsubstitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_224{
            local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
        }
    }

    for round in (1..(constants::ROUNDS_256_224-1)).rev(){
        //minus round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_224{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
        //unmix_columns
        for c in 0..constants::BLOCK_COLUMNS_256_224{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_REVERSE[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_REVERSE[r][i]);
                }
            }
        }

        //unrotate_rows
        for r in 1..4{
        let shift : usize = constants::SHIFTS_256_224[r];
        for i in (constants::BLOCK_COLUMNS_256_224-shift)..constants::BLOCK_COLUMNS_256_224{
            buffer[i+shift-constants::BLOCK_COLUMNS_256_224] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_256_224).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
        }

        //unsubstitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_224{
                local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
            }
        }


    }

    //minus round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_224{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }

    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_256_224{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}

/***************************************************************************************************
 * function name:  expand_key_(KEY_SIZE)_(BLOCK_SIZE)
 *
 * function:       (self explanatory)
 *
 * arguments:      expanded_key = the expanded key to use
 *                 key = raw key bits
 *
 * return:         void
 *
 * notes:          (none)
 **************************************************************************************************/


pub fn print_key_expansion_256_256(expanded_key : & [[[u8;constants::BLOCK_COLUMNS_256_256];4];constants::ROUNDS_256_256]){
    for i in 0..constants::ROUNDS_256_256{
        for c in 0..constants::BLOCK_COLUMNS_256_256{
            for r in 0..4{
                print!("{:02X} ",expanded_key[i][r][c]);
            }
        }
        println!();
    }
    println!();
}


fn print_block_256_256(message : &str, block : &[[u8;constants::BLOCK_COLUMNS_256_256];4]){
    println!("{}", message);
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_256{
            print!("{:02X} ", block[r][c]);
        }
        println!();
    }
    println!();
}

fn combo_move_256_256(temp :&mut  [[u8;constants::KEY_COLUMNS_256_256];4], round_constant_index : usize){
    for r in 0..4{
        temp[r][0] ^= constants::SBOX_FORWARD[temp[(r+1)%4][constants::KEY_COLUMNS_256_256-1] as usize];
    }
    temp[0][0] ^= constants::ROUND_CONSTANTS[round_constant_index];
}
fn swoosh_move_256_256(temp  : &mut [[u8;constants::KEY_COLUMNS_256_256];4] ){
    /*
    if constants::KEY_COLUMNS_256_256 < 6{

        for c in 1..constants::KEY_COLUMNS_256_256{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }

    } else {
    */
        for c in 1..4{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
        for r in 0..4{
            temp[r][4] ^= constants::SBOX_FORWARD[(temp[r][3])as usize];
        }
        for c in 5..constants::KEY_COLUMNS_256_256{
            for r in 0..4{
                temp[r][c] ^= temp[r][c-1];
            }
        }
    /*
    }
    */
}
fn load_move_256_256(temp : &[[u8;constants::KEY_COLUMNS_256_256];4],
expand_key : &mut [[[u8;constants::BLOCK_COLUMNS_256_256];4];constants::ROUNDS_256_256],
loads : usize,
expand_key_counter : &mut Counter){
    for c in 0..loads{
        for r in 0..4{
            expand_key[expand_key_counter.i][expand_key_counter.r][expand_key_counter.c]=temp[r][c];
            expand_key_counter.increment();
        }
    }
}

pub fn expand_key_256_256(key : &[u8;constants::KEY_BYTES_256_256],
expanded_key : &mut [[[u8;constants::BLOCK_COLUMNS_256_256];4];constants::ROUNDS_256_256]){
    //load into a local variable
    let mut round_constant_index : usize = 0;
    let mut temp : [[u8;constants::KEY_COLUMNS_256_256];4] =[[0;constants::KEY_COLUMNS_256_256];4];
    let mut expand_key_counter : Counter = Counter::new(constants::ROUNDS_256_256, constants::BLOCK_COLUMNS_256_256);
	let total_columns_needed : usize = constants::ROUNDS_256_256*constants::BLOCK_COLUMNS_256_256-constants::KEY_COLUMNS_256_256;
    let key_expansion_rounds_needed :usize = total_columns_needed/constants::KEY_COLUMNS_256_256;
    let key_expansion_remainder : usize = total_columns_needed%constants::KEY_COLUMNS_256_256;

    //load key into temporary matrix
    for c in 0..constants::KEY_COLUMNS_256_256{
        for r in 0..4{
            temp[r][c] = key[round_constant_index];
            round_constant_index+=1;
        }
    }
    //move temp into expanded key
    load_move_256_256(&temp, expanded_key, constants::KEY_COLUMNS_256_256, &mut expand_key_counter);
    //processing different for each type
    for round_constant_index in 1..key_expansion_rounds_needed+1{
        combo_move_256_256(&mut temp, round_constant_index);
        swoosh_move_256_256(&mut temp);
        load_move_256_256(&temp, expanded_key, constants::KEY_COLUMNS_256_256, &mut expand_key_counter);
    }
    if key_expansion_remainder > 0{
        combo_move_256_256(&mut temp, key_expansion_rounds_needed+1);
        swoosh_move_256_256(&mut temp);
        load_move_256_256(&temp, expanded_key, key_expansion_remainder, &mut expand_key_counter);
    }

}

pub fn encrypt_block_256_256(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_256_256];4];constants::ROUNDS_256_256],
input_block : & [u8;constants::BLOCK_BYTES_256_256],
destination_block : &mut [u8;constants::BLOCK_BYTES_256_256]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_256_256];4] = [[0;constants::BLOCK_COLUMNS_256_256];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_256_256];4];constants::ROUNDS_256_256] =
								[[[0;constants::BLOCK_COLUMNS_256_256];4];constants::ROUNDS_256_256];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_256_256{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_256{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_256_256{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }
    //add round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_256{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }
    //PROCESS ROUNDS
    for round in 1..(constants::ROUNDS_256_256-1){
        //substitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_256{
                local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
            }
        }

        //rotate rows
        for r in 1..4{
            let shift : usize = constants::SHIFTS_256_256[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_256_256-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_256_256-shift)..constants::BLOCK_COLUMNS_256_256{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_256_256];
            }
        }
        //mix_columns
        for c in 0..constants::BLOCK_COLUMNS_256_256{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_FORWARD[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_FORWARD[r][i]);
                }
            }
        }
        //add round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_256{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
    }
    //substitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_256{
            local_block[r][c] = constants::SBOX_FORWARD[(local_block[r][c])as usize];
        }
    }
    //rotate rows
    for r in 1..4{
            let shift : usize = constants::SHIFTS_256_256[r];
            for i in 0..shift{ //assign overflow values to tempBuffer
                buffer[i] = local_block[r][i];}
            for c in 0..(constants::BLOCK_COLUMNS_256_256-shift){//shift the values
                local_block[r][c] = local_block[r][c+shift];
            }
            for i in (constants::BLOCK_COLUMNS_256_256-shift)..constants::BLOCK_COLUMNS_256_256{//put the overflow values back
                local_block[r][i] = buffer[i+shift-constants::BLOCK_COLUMNS_256_256];
            }
    }
    //add final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_256{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_256_256-1][r][c];
        }
    }
    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_256_256{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}


pub fn decrypt_block_256_256(
expanded_key : & [[[u8;constants::BLOCK_COLUMNS_256_256];4];constants::ROUNDS_256_256],
input_block : & [u8;constants::BLOCK_BYTES_256_256],
destination_block : &mut [u8;constants::BLOCK_BYTES_256_256]){
    let mut local_block : [[u8;constants::BLOCK_COLUMNS_256_256];4] = [[0;constants::BLOCK_COLUMNS_256_256];4];
    let mut local_expanded_key:[[[u8;constants::BLOCK_COLUMNS_256_256];4];constants::ROUNDS_256_256] =
								[[[0;constants::BLOCK_COLUMNS_256_256];4];constants::ROUNDS_256_256];
	let mut buffer : [u8;4] = [0;4];
	let mut index : usize = 0;

    //local copy of expanded_key
    for i in 0..constants::ROUNDS_256_256{
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_256{
                local_expanded_key[i][r][c] = expanded_key[i][r][c];
            }
        }
    }

    //local copy of the block
    for c in 0..constants::BLOCK_COLUMNS_256_256{
        for r in 0..4{
            local_block[r][c] = input_block[index];
            index+=1;
        }
    }

    //minus final key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_256{
            local_block[r][c] ^= local_expanded_key[constants::ROUNDS_256_256-1][r][c];
        }
    }

    //unrotate_rows
    for r in 1..4{
        let shift : usize = constants::SHIFTS_256_256[r];
        for i in (constants::BLOCK_COLUMNS_256_256-shift)..constants::BLOCK_COLUMNS_256_256{
            buffer[i+shift-constants::BLOCK_COLUMNS_256_256] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_256_256).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
    }

    //unsubstitute
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_256{
            local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
        }
    }

    for round in (1..(constants::ROUNDS_256_256-1)).rev(){
        //minus round key
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_256{
                local_block[r][c] ^= local_expanded_key[round][r][c];
            }
        }
        //unmix_columns
        for c in 0..constants::BLOCK_COLUMNS_256_256{
            for r in 0..4 {buffer[r] = local_block[r][c];}
            for r in 0..4 {
                local_block[r][c] = multilply_gf256(buffer[0],constants::MDS_REVERSE[r][0]);
                for i in 1..4 {
                    local_block[r][c] ^= multilply_gf256(buffer[i],constants::MDS_REVERSE[r][i]);
                }
            }
        }

        //unrotate_rows
        for r in 1..4{
        let shift : usize = constants::SHIFTS_256_256[r];
        for i in (constants::BLOCK_COLUMNS_256_256-shift)..constants::BLOCK_COLUMNS_256_256{
            buffer[i+shift-constants::BLOCK_COLUMNS_256_256] = local_block[r][i]; //load values into buffer
        }

        for c in (shift..constants::BLOCK_COLUMNS_256_256).rev(){
            local_block[r][c] = local_block[r][c-shift];
        }
        for i in 0..shift{//put the overflow values back
            local_block[r][i] = buffer[i];
        }
        }

        //unsubstitute
        for r in 0..4{
            for c in 0..constants::BLOCK_COLUMNS_256_256{
                local_block[r][c] = constants::SBOX_REVERSE[(local_block[r][c])as usize];
            }
        }


    }

    //minus round key
    for r in 0..4{
        for c in 0..constants::BLOCK_COLUMNS_256_256{
            local_block[r][c] ^= local_expanded_key[0][r][c];
        }
    }

    //copy to destination_block
    index=0;
    for c in 0..constants::BLOCK_COLUMNS_256_256{
        for r in 0..4{
            destination_block[index] = local_block[r][c];
            index+=1;
        }
    }
}
